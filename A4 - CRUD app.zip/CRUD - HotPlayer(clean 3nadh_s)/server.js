var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
const path = require('path');
var config = require('config');
const redis = require('redis');
const client = redis.createClient(config.get('session.redisConfig.port'), config.get('session.redisConfig.host'));
const helmet = require('helmet');
var session = require('express-session');
var RedisStore = require('connect-redis')(session);
var Q = require('q');

let constants = require('constants');
var https = require('https');
var fs = require('fs');
var tls = require('tls');
tls.CLIENT_RENEG_LIMIT = 0;
tls.CLIENT_RENEG_WINDOW = 1 / 0;

//DB dependencies
var http = require('http');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/3nadhDB";

var app = express();

/* if (process.env.NODE_ENV == 'qa' || process.env.NODE_ENV == 'prod') {
  require("appdynamics").profile({
    accountAccessKey: fs.readFileSync('/run/secrets/app_dynamic_ac_access_key', 'utf8').replace('\n', ''),
    tierName: 'FRAMEWORK-UI',
    nodeName: process.env.HOSTNAME  // The controller will automatically append the node name with a unique number
  });
} */

var myLogger = function (req, res, next) {
  console.log('LOGGER', req.body, req.headers, req.query);
  //Handle Logs better from here
  next()
}

app.use(myLogger)
app.use(bodyParser.json({
  limit: '50mb'
})); // support json encoded bodies
app.use(bodyParser.urlencoded({
  parameterLimit: 100000,
  limit: '50mb',
  extended: true
})); // support encoded bodies

app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);

// Use the session middleware
app.use(session({
  store: new RedisStore({
    "client": client
  }),
  secret: config.get('session.secret'), // this will be changed to a much more dynamic key
  resave: true,
  saveUninitialized: true,
  cookie: {
    secure: true,
    sid: "",
    maxAge: 300 * 1000 //5 minutes for now.
  },
}));

// Point static path to dist
app.use(express.static(path.join(__dirname, 'dist')));
// app.use(cors());

// To protect the express endpoints from casual attacks.
app.use(helmet());

// 'Delete' request from Browser(A2)
app.get('/deleteIt/:patronNo', (req, res) => { 
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var myobj = { patronNo: req.params.patronNo };
    db.collection("hotPlayer").deleteOne(myobj,       
      function(err, result) {
        if (err){
            console.warn(err.message);  
            db.close();
        }else{
            //console.dir(result);
            console.log("document deleted");
            res.send(result);
            db.close();
        }
      }
    );
  });
});

// 'put' request from Browser(A2)
app.get('/modifyIt/:patronNo/:checkin/:checkout', (req, res) => { 
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    db.collection('hotPlayer').findOneAndUpdate(
      {patronNo: req.params.patronNo}, // query
      //[['_id','asc']],  // sort order
      {$set: {"booking.0.checkin": req.params.checkin, "booking.0.checkout": req.params.checkout}}, // replacement, replaces only the field "address"
      //{}, // options
      function(err, result) {
        if (err){
            console.warn(err.message);  
            db.close();
        }else{
            //console.dir(result);
            console.log("document updated");
            res.send(result);
            db.close();
        }
      }
    );
  });
});

// 'post' request from Browser(A2)
app.get('/addIt/:patronNo/:patronLastName/:tier/:location/:theo/:lastRatingTime/:codedHost/:hostName/:dept/:checkin/:checkout', (req, res) => { 
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var myobj = {
      patronNo: req.params.patronNo,
      tier: req.params.tier,
      location: req.params.location,
      theo: req.params.theo,
      patronLastName: req.params.patronLastName,
      lastRatingTime: req.params.lastRatingTime,
      codedHost: req.params.codedHost,
      hostName: req.params.hostName,
      booking: [
        {
          dept: req.params.dept,
          checkin: req.params.checkin,
          checkout: req.params.checkout
        }
      ]
    }
    db.collection("hotPlayer").insertOne(myobj,       
      function(err, result) {
        if (err){
            console.warn(err.message);  
            db.close();
        }else{
            //console.dir(result);
            console.log("document inserted");
            res.send(result);
            db.close();
        }
      }
    );
  });
});

// 'get' request from Browser(A2)
app.get('/getAll', (req, res) => { 
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    db.collection("hotPlayer").find({}).toArray(function(err, result) {
      if (err) throw err;
      res.send(result);
      db.close();
    });
  });
});

// Catch all static json files
app.get('/app/*', (req, res) => {
  res.sendFile(path.join(__dirname, `src/app/${req.params[0]}`));
});

// Catch all other routes and return the index file
app.get('/*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/indexMApp.html'));
});

const port = process.env.PORT || config.get('expressServer.port');

app.listen(port, function () {
  console.log("App Started on PORT " + port);
});

// var tlsOptions = {
//   key: fs.readFileSync('/run/secrets/3nadh-resorts-ca-key'),
//   cert: fs.readFileSync('/run/secrets/3nadh-resorts-ca-pem'),
//   requestCert: true,
//   rejectUnauthorized: false
// };

// const sslport = process.env.SSL_PORT || config.get('expressServer.sslport');

// https.createServer(tlsOptions, app).listen(sslport, function () {
//   console.log("App HTTPS Started on PORT " + sslport);
// });