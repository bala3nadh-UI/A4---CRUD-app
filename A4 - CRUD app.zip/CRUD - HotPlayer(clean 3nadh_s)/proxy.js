var express = require('express')
var app = express()
var bodyParser = require('body-parser');
app.use(bodyParser.json());

app.post('/test', function (req, res) {
  console.log('hello',req.headers);
  console.log("data",JSON.stringify(req.body));
  res.json({'greet':'Hello World!'});
})

app.listen(3001, function () {
  console.log('Example app listening on port 3001!')
})