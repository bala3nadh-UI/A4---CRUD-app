var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
const path = require('path');
var config = require('config');
const redis = require('redis');
const client = redis.createClient(config.get('session.redisConfig.port'), config.get('session.redisConfig.host'));
const helmet = require('helmet');
var session = require('express-session');
var RedisStore = require('connect-redis')(session);
var proxy = require('express-http-proxy');
var request = require('request');
const api = require('./server/routes/api');
const reports = require('./server/routes/reports');
const url = require('url');
var phantom = require('phantom');
var Q = require('q');
const uuidv4 = require('uuid/v4');

let constants = require('constants');
var https = require('https');
var fs = require('fs');
var tls = require('tls');
tls.CLIENT_RENEG_LIMIT = 0;
tls.CLIENT_RENEG_WINDOW = 1 / 0;

var app = express();

if (process.env.NODE_ENV == 'qa' || process.env.NODE_ENV == 'prod') {
  require("appdynamics").profile({
    accountAccessKey: fs.readFileSync('/run/secrets/app_dynamic_ac_access_key', 'utf8').replace('\n', ''),
    tierName: '3nadh-App-UI',
    nodeName: process.env.HOSTNAME  // The controller will automatically append the node name with a unique number
  });
}

var myLogger = function (req, res, next) {
  console.log('LOGGER', req.body, req.headers, req.query);
  //Handle Logs better from here
  next()
}

app.use(myLogger)
app.use(bodyParser.json({
  limit: '50mb'
})); // support json encoded bodies
app.use(bodyParser.urlencoded({
  parameterLimit: 100000,
  limit: '50mb',
  extended: true
})); // support encoded bodies

app.use(function (req, resp, next) {
  if (cors(req, resp)) {
    next();
  } else {
    resp.status(401).end();
  }
})

app.options('*', function (req, resp) {
  if (cors(req, resp)) {
    resp.status(200).end();
  } else {
    resp.status(401).end();
  }
})

var cors = function (req, resp) {
  var origin = req.headers.origin
  var env = app.get('env')
  //default NODE_ENV = development
  if (origin) {
    if (env === 'dev' || env === 'development' || origin.endsWith(config.get("cors.domainSuffix"))) {
      //for development, allow all origin
      //other environment, only allow origin with .3nadh-resorts.com as suffixS
      resp.header("Access-Control-Allow-Origin", origin)
      resp.header("Access-Control-Allow-Methods", "OPTIONS,GET,HEAD,PUT,PATCH,POST,DELETE")
      resp.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-sid, end-point-domain, stationid, env")
      resp.header("Access-Control-Max-Age", 60)
      return true
    } else {
      return false
    }
  } else {
    return true
  }

}

//Extend this route for custom purposes.
app.use('/api', api);
app.use('/reports', reports);

app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);

// Use the session middleware
app.use(session({
  store: new RedisStore({
    "client": client
  }),
  secret: config.get('session.secret'), // this will be changed to a much more dynamic key
  resave: true,
  saveUninitialized: true,
  cookie: {
    secure: true,
    sid: "",
    maxAge: 300 * 1000 //5 minutes for now.
  },
}));

// Point static path to dist
app.use(express.static(path.join(__dirname, 'dist')));
// app.use(cors());

// To protect the express endpoints from casual attacks.
app.use(helmet());

// Get Access Token
var getAccessToken = function (req, res, next) {
  // Parse SID from header
  let sid = req.headers['x-sid'];
  if (typeof sid == 'undefined') {
    //Not Authenticated
    return res.status(401).json({
      "isAuthenticated": false,
      "message": "Invalid Token"
    });
  }
  //Get all keys for the SID from storage
  client.hgetall(sid, function (err, obj) {
    if (!obj) {
      //Not Authenticated if the SID doesnt have any object stored
      return res.status(401).json({
        "isAuthenticated": false,
        "message": "Invalid Token"
      });
    };
    //Current DateTime
    var now = new Date();
    var tokenExpiresOn = new Date(obj.expiresOn);
    if (tokenExpiresOn.getTime() < now.getTime()) {
      //ExpiresOn is Passed current Time
      //Data To get new Token
      var data = {
        headers: {
          'Authorization': config.get('microservices.oauth.authorizationDigest')
        },
        method: 'POST',
        json: true,
        url: config.get('microservices.oauth.tokenURL'),
        formData: {
          "client_id": config.get('microservices.oauth.formData.client_id'),
          "client_secret": config.get('microservices.oauth.formData.client_secret'),
          "grant_type": "refresh_token",
          "refresh_token": obj.refresh_token
        }
      };
      request.post(data, function (err, httpResponse, body) {
        //Current API hit Time + (Expires Time (Will be coming in Seconds)*1000)
        var bodyData = body;
        bodyData.expiresOn = new Date(now.getTime() + (1000 * bodyData.expires_in));
        client.hmset(sid, bodyData, function (err, res) {
          // New acccess token obtained
          console.log('New acccess token obtained');
        });
        next();
      });
    } else {
      req.headers["Authorization"] = "Bearer " + obj.access_token;
      next();
    }
    // Check method ends
  });
}

let getAPIToken = (req, res) => {
  //console.log(req)
  let sid = req.query["sid"];
  client.hgetall(sid, function (err, obj) {
    if (obj) {
      return res.status(200).json(obj);
    } else {
      return res.status(200).json({
        "status": "ERROR",
        "message": "Access Token is not available for the requested user."
      });
    }
  });
}

//Check Permissions
let getPermissions = (req, res) => {
  let sid = req.headers['x-sid'];
  client.hgetall(sid, function (err, obj) {
    if (!obj) {
      return res.status(401).json({
        "isAuthenticated": false,
        "message": "Your current session is expired, please login again."
      });
    }
    let options = {
      method: 'GET',
      json: true,
      // qs: {
      //   access_token: obj.access_token
      // },
      headers: {
        Authorization: "Bearer " + obj.access_token
      },
      url: config.get('microservices.permissions')
    }
    //Disable Permission Check
    var disablePermissionCall = false;
    if (disablePermissionCall) {
      return res.status(200).json({
        "success": "SUCCESS",
        "isSupervisor": true,
        "message": "Authenticated Successfully"
      });
    } else
      request.get(options, function (err, response, body) {
        if (err) {
          return res.status(err.statusCode || 500).json(err.body || {
            message: "Error Occured.",
            data: err
          });
        }
        return res.status(response.statusCode).json(body);
      });
  });
};
//Remove Session
let removeSession = (req, res) => {
  let sid = req.headers['x-sid'];
  req.session.destroy();
  client.del(sid);
  return res.status(200).json({
    "data": sid,
    "message": "Session Cleared"
  });
};

var deviceAuthen = function (req, res, next) {
  console.log("req.headers : ", req.headers);
  var cert;
  try {
    cert = req.socket.getPeerCertificate(true);
  } catch (e) {
    console.log(e);
  }
  var isInvalidCert = !cert || !Object.keys(cert).length;
  let stationId = req.headers['stationid'];

  if (isInvalidCert && !stationId) {
    return res.status(401).json({ "isAuthenticated": false, "message": "Unauthorized Device." });
  }
  req.headers["X-3nadh-App-Console-ID"] = isInvalidCert ? "" : cert.subject.CN.toString('base64');
  req.headers["X-3nadh-App-Station-ID"] = stationId;
  next();
}

app.use('/proxy', getAccessToken, proxy(config.get('microservices.apiGateway'), {
  decorateRequest: function (proxyReq, originalReq) {
    // you can update headers
    console.log("original session ID in proxy", originalReq.path);
    console.log("Proxy is : ", proxyReq.path);
    // let sid = originalReq.body.data.sid;
    // delete originalReq.body.data.sid;
    return proxyReq;
  }
}));

app.use('/embedToken', getAccessToken, deviceAuthen, proxy('localhost', {
  https: false,
  decorateRequest: function (proxyReq, originalReq) {
    // you can update headers
    console.log("original session ID in proxy", originalReq.path);
    console.log("Proxy is : ", proxyReq.path);

    let portNo = (originalReq.headers['end-point-domain'].indexOf("https://") !== -1) ? '443' : '80';
    let endpoint = originalReq.headers['end-point-domain'].replace('http://', '').replace('https://', '');

    if (process.env.NODE_ENV == 'prod') {
      endpoint = originalReq.headers['end-point-domain'];
    }

    let endpointArr = endpoint.split('/');
    let domainArr = endpointArr.shift().split(':');

    proxyReq.hostname = domainArr[0];
    proxyReq.port = (domainArr.length < 2) ? portNo : domainArr[1];
    proxyReq.path = '/' + endpointArr.join('/');

    delete originalReq.headers['end-point-domain'];
    // let sid = originalReq.body.data.sid;
    // delete originalReq.body.data.sid;

    delete proxyReq.headers['origin'];
    console.log("proxyReq.headers : ", proxyReq.headers);
    return proxyReq;
  }
}));

app.use('/embedTokenWithUpload', getAccessToken, deviceAuthen, function (req, res) {
  let endpoint = req.headers['end-point-domain'];
  delete req.headers['end-point-domain'];

  req.pipe(request(endpoint)).pipe(res);
});

app.post('/logoff', getAccessToken, removeSession);
app.post('/permissions', getAccessToken, getPermissions);
app.get('/token', getAPIToken);

app.use('/pxy/upload/:endpoint(*+)', getAccessToken, deviceAuthen, function (req, res) {
  console.log('endpoint', req.params.endpoint);

  //Find apiPrefix to map the actual domain. Note - endpoint should also specify environment and service name. e.g. /pxy/upload/qa/patron/api/patron-mgnt/v1
  var match = req.params.endpoint.match("(.*?)/(.*?)/(.*)")
  console.log('matched API path', match)

  //match[1] = environment, i.e. dev, sit, qa ...
  //match[2] = service name, i.e. patron, itadmin ...
  let domain = config.get('endpointDomains.' + match[1] + '.' + match[2])
  let actualApiEndpoint = match[3]

  //TODO rount to new domain
  let destination = domain + actualApiEndpoint;

  console.log('Destination', destination)

  req.pipe(request(destination)).pipe(res);
});

var formData = Object.assign({}, config.get('microservices.oauth.formData'));

// headers: { 'Content-Type': 'application/json' },{

app.post('/menuProfile', getAccessToken, function (req, res) {
  let sid = req.headers['x-sid'];
  client.hgetall(sid, function (err, obj) {
    //console.log(obj);
    if (!obj) {
      return res.status(401).json({
        "isAuthenticated": false,
        "message": "Your current session is expired, please login again."
      });
    }
    let options = {
      method: 'POST',
      url: config.get('microservices.menuProfile'),
      // qs: {
      //   access_token: obj.access_token
      // },
      headers: {
        Authorization: "Bearer " + obj.access_token,
        'cache-control': 'no-cache',
        'content-type': 'application/json'
      },
      body: req.body,
      json: true
    };
    request(options, function (err, response, body) {
      //console.log(body)
      if (err) {
        console.log(err)
        return res.status(err.statusCode || 500).json(err.body || []);
      }
      if (body && body.data) {
        return res.status(200).json(body.data);
      } else {
        return res.status(response.statusCode).json(body);
      }
    });
  });
})

//Supervisor Login
app.post('/supervisorAccess', function (req, finalRes) {
  let requestBody = req.body;
  // console.log(requestBody);
  if (typeof requestBody.username == 'undefined' || typeof requestBody.password == 'undefined') {
    return finalRes.status(401).json({
      "isAuthenticated": false,
      "message": "Invalid message body, please dont send post body as form data, just use url encoded body parameter"
    });
  }
  formData.username = requestBody.username;
  formData.password = requestBody.password;
  request.post({
    headers: {
      'Authorization': config.get('microservices.oauth.authorizationDigest')
    },
    url: config.get('microservices.oauth.tokenURL'),
    formData: formData
  }, (err, res, tokenBody) => {
    // console.log("Token", tokenBody);
    var token = JSON.parse(tokenBody);

    var name = token.name;
    // var name = "";
    // var nameArr = requestBody.username.split('\\');
    // if (nameArr.length > 1){
    //   nameArr.splice(0,1);
    //   name = nameArr.join('\\');
    // } else {
    //   name = nameArr[0];
    // }
    // console.log("name", name);
    let options = {
      method: 'GET',
      json: true,
      // qs: {
      //   access_token: token.access_token
      // },
      headers: {
        Authorization: "Bearer " + token.access_token
      },
      url: config.get('microservices.permissions')
    }
    //Check if User Login SuccessFull
    if (token.error) {
      return finalRes.status(200).json({
        "status": "FAILED",
        "isSupervisor": false,
        "message": token.error_description
      });
    }
    //Disable Permission Check
    var disablePermissionCall = false;
    if (disablePermissionCall) {
      return finalRes.status(200).json({
        "status": "SUCCESS",
        "isSupervisor": true,
        "message": "Authenticated Successfully"
      });
    } else
      request.get(options, function (err, response, permissionsBody) {
        if (err) {
          return finalRes.status(err.statusCode || 500).json(err.body || {
            message: "Error Occured."
          });
        }
        var responseData = {};
        var responseStatus = 401;
        //Authentication
        if (response.statusCode == 200) {
          //User authentication was success
          responseData.status = "SUCCESS";

          var roles = config.get("supervisorUserRoles");
          var permissionRoles = permissionsBody["data"]["roles"];

          // Set Default Value to not supervisor user.
          responseData.isSupervisor = false;
          responseData.message = "No Supervisor Privilages for the user";

          // For each role from config file check if its present in API response user roles
          roles.forEach(role => {
            if (permissionRoles.indexOf(role) > -1) {
              //One Role got matched and user is supervisor
              responseStatus = 200;
              responseData.isSupervisor = true;
              responseData.name = name;
              responseData.message = "Authenticated Successfully";
            }
          });
        } else {
          //User credentials are invalid and not authenticated
          responseStatus = 401;
          responseData.status = "FAILED";
          responseData.isSupervisor = false;
          responseData.message = "User is not a supervisor or equivalent.";
        }
        return finalRes.status(responseStatus).json(responseData);
      });
  });
});

//User Login
app.post('/access', function (req, res) {
  //console.log("data", req.body);
  var requestBody = req.body;
  if (typeof requestBody.username == 'undefined' || typeof requestBody.password == 'undefined') {
    console.error('Invalid Request Body'); //change this message during production to make it more generic than specific.
    return res.status(401).json({
      "isAuthenticated": false,
      "message": "Invalid message body, please dont send post body as form data, just use url encoded body parameter"
    });
  }
  formData.username = requestBody.username;
  formData.password = requestBody.password;
  formData.station = requestBody.station;
  //console.log(formData, requestBody);
  request.post({
    headers: {
      'Authorization': config.get('microservices.oauth.authorizationDigest')
    },
    url: config.get('microservices.oauth.tokenURL'),
    formData: formData
  }, function optionalCallback(err, httpResponse, body) {
    if (err || httpResponse.statusCode != 200) {
      console.error('Error - OAUTH server is unhappy about the credentials :) ', err | httpResponse.statusCode);
      return res.status(401).json({
        "isAuthenticated": false,
        "message": "Error - OAUTH server is unhappy about the credentials :)"
      });
    }
    var bodyData = JSON.parse(body);
    req.session.sid = bodyData.jti;
    //console.log("setting ", req.sessionID, bodyData.jti);
    //console.log("return ", bodyData );

    var now = new Date();
    //Current Time + (Expires Time (Will be coming in Seconds)*1000)
    bodyData.expiresOn = new Date(now.getTime() + (1000 * bodyData.expires_in));

    // var response = { "isAuthenticated": true, "sid": bodyData.jti };
    var response = {
      "isAuthenticated": true,
      "sid": bodyData.jti,
      "userName": bodyData.displayName,
      "userID": bodyData.name,
      "userDepartmentID": bodyData.department,
      "stationID": formData.station
    };
    //console.log('bodyData', bodyData);
    //console.log('response', response);
    if (req.body.isSupervisor) {
      //do nothing for now
      response.isSupervisorAuthenticated = true;
    } else {
      // Session is set with access token object in the redis cluster.
      client.hmset(bodyData.jti, bodyData, function (err, res) {
        console.log(err, res);
      });
    }
    //console.log('before get permission array', response);
    //console.log('User Authentication successful', body, httpResponse.statusCode); //change this message during production to make it more generic than specific.

    request.get({
      headers: {
        'Authorization': 'Bearer ' + bodyData.access_token
      },
      url: config.get('microservices.userPermissionEndpoint')
    }, function optionalCallback(err, httpResponse, body) {
      //console.log('Get Resource Permission');
      if (err || httpResponse.statusCode != 200) {
        console.error('Error - Unable to obtain permission resources ', err);
        return res.status(401).json({
          "isAuthenticated": false,
          "message": "Error - Unable to obtain permission resources"
        });
      }
      var permissionBodyData = JSON.parse(body);
      //console.log('Permission data', permissionBodyData.data);
      response['permissionObj'] = permissionBodyData.data;

      //console.log('after get permission array', response);
      if (!response.userName) {
        response['userName'] = "";
      }
      return res.status(200).json(response);
    });

  });
});

app.use('/client', function (req, res) {
  // Obtain certificate details
  var cert;
  try {
    cert = req.socket.getPeerCertificate(true);
  } catch (e) {
    console.log(e);
  }
  if (!cert || !Object.keys(cert).length) {
    // Handle the bizarre and probably not-real case that a certificate was
    // validated but we can't actually inspect it
    return res.status(401).send('Certificate information could not be retrieved.');
  }

  res.contentType('application/json');
  res.send({
    'cid': cert.subject.CN.toString('base64')
  });
});

app.post('/convertPdf', function (req, res) {
  //console.log("Going to convert pdf");
  var pageWidth = req.body.pageWidth;
  var pageHeight = req.body.pageHeight;
  var htmlStrings = req.body.htmlStrings;
  for (var i = 0; i < htmlStrings.length; i++)
    htmlStrings[i] = decodeURIComponent(htmlStrings[i]);

  var dir = 'convertjobs';
  if (!fs.existsSync(dir)) fs.mkdirSync(dir);

  var jobCount = 0;
  var dataArray = [];

  convertPDF();

  function convertPDF() {
    var uuid = uuidv4();
    console.log("Converting job: " + uuid);
    var htmlFile = dir + '/printslip_' + uuid + '.html';
    var pdfFile = dir + '/printslip_' + uuid + '.pdf';

    if (jobCount < htmlStrings.length) {

      // Write htmlString to an HTML file
      fs.writeFile(htmlFile, htmlStrings[jobCount], function (err) {
        if (err) return console.log("Unable to write file: " + err);
      });

      // Use Phantom to convert HTML to PDF
      var _ph, _page, _outObj;
      phantom.create().then(ph => {
        _ph = ph;
        return _ph.createPage();
      }).then(page => {
        _page = page;
        return _page.open(htmlFile);
      }).then(status => {
        return _page.property('content')
      }).then(content => {
        // _page.paperSize = { width: pageWidth, height: pageHeight, margin: '0' };
        // _page.property('viewportSize', { width: pageWidth, height: pageHeight });
        _page.property('paperSize', {
          width: pageWidth,
          height: pageHeight
        });
        _page.render(pdfFile).then(temp => {

          // Read PDF data to call print service
          fs.readFile(pdfFile, function (err, data) {
            if (err) return console.log("Unable to read file: " + err);

            dataArray.push(Array.from(new Uint8Array(data)));

            // Delete the temporary files
            fs.unlink(htmlFile, function (err) {
              if (err) return console.log("Unable to delete HTML file: " + err);
            });
            fs.unlink(pdfFile, function (err) {
              if (err) return console.log("Unable to delete PDF file: " + err);
            });

            // Self-call next print job
            console.log('jobCount: ' + jobCount)
            console.log('htmlStrings.length: ' + htmlStrings.length)
            jobCount++;
            convertPDF(jobCount);

          });
        });

        _page.close();
        _ph.exit();

      }).catch(e => console.log(e));

    } else {
      //Output byteArray
      return res.status(200).json({
        'bArray': dataArray
      });
    }

  }
});

app.post('/printPdf', getAccessToken, function (req, res) {
  //console.log("Going to print pdf");
  var pageWidth = req.body.pageWidth;
  var pageHeight = req.body.pageHeight;
  var printerName = req.body.printerName;
  var user = req.body.user;
  var paperSize = req.body.paperSize;
  var htmlStrings = req.body.htmlStrings;
  for (var i = 0; i < htmlStrings.length; i++)
    htmlStrings[i] = decodeURIComponent(htmlStrings[i]);

  var printCount = 0;
  var errors = '';

  var dir = 'printjobs';
  if (!fs.existsSync(dir)) fs.mkdirSync(dir);

  var jobCount = 0;
  convertPDF(jobCount);

  function convertPDF(jobCount) {
    var uuid = uuidv4();
    console.log("Printing job: " + uuid);
    var htmlFile = dir + '/printslip_' + uuid + '.html';
    var pdfFile = dir + '/printslip_' + uuid + '.pdf';

    // Write htmlString to an HTML file
    fs.writeFile(htmlFile, htmlStrings[jobCount], function (err) {
      if (err) return console.log("Unable to write file: " + err);
    });

    // Use Phantom to convert HTML to PDF
    var _ph, _page, _outObj;
    phantom.create().then(ph => {
      _ph = ph;
      return _ph.createPage();
    }).then(page => {
      _page = page;
      return _page.open(htmlFile);
    }).then(status => {
      return _page.property('content')
    }).then(content => {
      // _page.paperSize = { width: pageWidth, height: pageHeight, margin: '0' };
      // _page.property('viewportSize', { width: pageWidth, height: pageHeight });
      _page.property('paperSize', {
        width: pageWidth,
        height: pageHeight
      });
      _page.render(pdfFile).then(temp => {

        // Read PDF data to call print service
        fs.readFile(pdfFile, function (err, data) {
          if (err) return console.log("Unable to read file: " + err);

          var arrayData = new Uint8Array(data);
          var reqData = {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': req.headers.Authorization
            },
            method: 'POST',
            url: config.get('endpointDomains.dev.printing') + 'api/proxy/v1/printer/printerjobs',
            json: true,
            body: {
              "correlationId": "1",
              "data": {
                "printerName": printerName,
                "noOfCopy": "1",
                "user": user,
                "jobName": 'job01',
                "pageLayout": 'POTRAIT',
                "fileName": pdfFile,
                "paperSize": paperSize,
                "contentType": 'PDF',
                "fitToPage": false,
                "otherPrintAttributes": {},
                "data": Array.from(arrayData)
              }
            }
          };

          request.post(reqData, function optionalCallback(err, httpResponse, body) {
            if (err || httpResponse.statusCode != 200) {
              console.error("Print Job [" + printCount + "] Failed", err);
              // errors = errors.concat("Print Job [" + printCount + "] Failed\n");
              errors = 'Print Failed';
            }

            printCount++;
            if (htmlStrings.length == printCount) {
              if (errors.length != 0)
                return res.status(400).json([{
                  "message": errors
                }]);
              else
                return res.status(200).json({
                  "message": "Print Success"
                });
            }

          });

          // Delete the temporary files
          fs.unlink(htmlFile, function (err) {
            if (err) return console.log("Unable to delete HTML file: " + err);
          });
          fs.unlink(pdfFile, function (err) {
            if (err) return console.log("Unable to delete PDF file: " + err);
          });

          // Self-call next print job
          jobCount++;
          if (htmlStrings.length > jobCount)
            convertPDF(jobCount);
        });
      });

      _page.close();
      _ph.exit();

    }).catch(e => console.log(e));

  }
});

app.post("/savePdf", function (req, res) {
console.log("savePDF");
console.log(req);  

  var pdfData = req.body.message;
  var htmlStrings = [];
  var htmlstring = `
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Print tab</title>
            <style>
            </style>
        </head>
        <body>` + pdfData + `</body>
        </html>`;

  htmlStrings.push(encodeURIComponent(htmlstring));

  for (var i = 0; i < htmlStrings.length; i++)
    htmlStrings[i] = decodeURIComponent(htmlStrings[i]);

  var printCount = 0;
  var errors = '';

  var dir = 'printedPdfs';
  if (!fs.existsSync(dir)) fs.mkdirSync(dir);

  var jobCount = 0;
  convertPDF(jobCount);

  function convertPDF(jobCount) {
    var uuid = req.body.user;
    var htmlFile = dir + '/registration_' + uuid + '.html';
    var pdfFile = dir + '/registration_' + uuid + '.pdf';

    // Write htmlString to an HTML file
    fs.writeFile(htmlFile, htmlStrings[jobCount], function (err) {
      if (err) return console.log("Unable to write file: " + err);
    });

    // Use Phantom to convert HTML to PDF
    var _ph, _page, _outObj;
    phantom.create().then(ph => {
      _ph = ph;
      return _ph.createPage();
    }).then(page => {
      _page = page;
      return _page.open(htmlFile);
    }).then(status => {
      return _page.property('content')
    }).then(content => {
      // _page.paperSize = { width: pageWidth, height: pageHeight, margin: '0' };
      // _page.property('viewportSize', { width: pageWidth, height: pageHeight });
      _page.property('paperSize', {
        width: 595,
        height: 842
      });
      _page.render(pdfFile).then(); //creates 'pdf'

      _page.close();
      _ph.exit();

    }).catch(e => console.log(e));

  }

  res.end(JSON.stringify({
    name: "Printed PDF"
  }));
});

app.use('/device', getAccessToken, function (req, res) {
  console.log("req.headers : ", req.headers);
  var deviceInfo;
  var cert;
  try {
    cert = req.socket.getPeerCertificate(true);
  } catch (e) {
    console.log(e);
  }
  var isInvalidCert = !cert || !Object.keys(cert).length;

  //TODO after front-end added env header, make strict env checking to ensure req.headers['env'] exist
  var itadminPath = config.get('endpointDomains.dev.itadmin') + "api/itadmin/v1";
  if (req.headers['env']) {
    itadminPath = config.get('endpointDomains.' + req.headers['env'] + '.itadmin') + "api/itadmin/v1";
  }

  let stationId = req.headers['stationid'];

  if (isInvalidCert && !stationId) {
    return res.status(401).send('Unauthorized Device.');
  } else if (isInvalidCert) {
    request.get({
      headers: {
        'Authorization': req.headers.Authorization
      },
      url: itadminPath + "/device/queryByStationId/" + stationId
    }, function optionalCallback(err, httpResponse, body) {
      console.log('Request : ', this.req._header);
      res.contentType('application/json');
      if (err || httpResponse.statusCode != 200) {
        console.error('Error - Unable to obtain device with status error code : ' + httpResponse.statusCode, err);
        return res.status(httpResponse.statusCode).send({
          'error': "Unable to obtain device by station ID : " + stationId
        });
      }
      return res.status(200).json(JSON.parse(body).payload);
    });
  } else {
    var consoleId = req.socket.getPeerCertificate(true).subject.CN.toString('base64');
    request.get({
      headers: {
        'Authorization': req.headers.Authorization
      },
      url: itadminPath + "/device/queryByConsoleId/" + consoleId
    }, function optionalCallback(err, httpResponse, body) {
      console.log('Request : ', this.req._header);
      res.contentType('application/json');
      if (err || httpResponse.statusCode != 200) {
        console.error('Error - Unable to obtain device with status error code : ' + httpResponse.statusCode, err);
        return res.status(httpResponse.statusCode).send({
          'error': "Unable to obtain device by console ID : " + cert.subject.CN.toString('base64')
        });
      }
      return res.status(200).json(JSON.parse(body).payload);
    });
  }
});

app.use('/test', function (req, res) {
  // Obtain certificate details
  var cert;
  try {
    cert = req.socket.getPeerCertificate(true);
  } catch (e) {
    console.log(e);
  }
  if (!cert || !Object.keys(cert).length) {
    // Handle the bizarre and probably not-real case that a certificate was
    // validated but we can't actually inspect it
    return res.status(401).send('Certificate information could not be retrieved.');
  }

  res.contentType('application/json');
  res.send({
    'cid': cert.subject.CN.toString('base64')
  });
});

app.get('/environment', (req, res) => {
  return res.status(200).json({"environment": process.env.NODE_ENV});
});

app.get('/_health', (req, res) => {
  return res.status(200).json({"message": 200});
});

app.get('/printedPdfs/*', (req, res) => {
  res.sendFile(path.join(__dirname, `printedPdfs/${req.params[0]}`));
});

app.get('/ftpPatronPhoto/*', (req, res) => {
  res.sendFile(path.join(__dirname, `ftpPatronPhoto/${req.params[0]}`));
});

// Catch all other routes and return 404
app.get('/*', (req, res) => {
  return res.status(404).json({"message": 404});
});

const port = process.env.PORT || config.get('expressServer.port');

app.listen(port, function () {
  console.log("App Started on PORT " + port);
});

var keyLocation = 'config/ssl/mce/ca.key'
var certLocation = 'config/ssl/mce/ca.crt'

if (process.env.NODE_ENV == 'prod') {
  keyLocation = '/run/secrets/3nadh-resorts-ca-key'
  certLocation = '/run/secrets/3nadh-resorts-ca-pem'
}

var tlsOptions = {
  key: fs.readFileSync(keyLocation),
  cert: fs.readFileSync(certLocation),
  requestCert: true,
  rejectUnauthorized: false
};

app.post("/ftpPatronPhoto", function (req, res) {
  console.log("ftpPatronPhoto");
  console.log(req);  
  
    var pdfData = req.body.message;
    var htmlStrings = [];
    var htmlstring = `
          <html>
          <head>
              <meta charset="UTF-8">
              <title>Print tab</title>
              <style>
              </style>
          </head>
          <body>` + pdfData + `</body>
          </html>`;
  
    htmlStrings.push(encodeURIComponent(htmlstring));
  
    for (var i = 0; i < htmlStrings.length; i++)
      htmlStrings[i] = decodeURIComponent(htmlStrings[i]);
  
    var printCount = 0;
    var errors = '';
  
    var dir = 'ftpPatronPhoto';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
  
    var jobCount = 0;
    convertPDF(jobCount);
  
    function convertPDF(jobCount) {
      var uuid = req.body.user;
      var htmlFile = dir + '/registration_' + uuid + '.html';
      var pdfFile = dir + '/registration_' + uuid + '.pdf';
  
      // Write htmlString to an HTML file
      fs.writeFile(htmlFile, htmlStrings[jobCount], function (err) {
        if (err) return console.log("Unable to write file: " + err);
      });
  
    }
    res.end(JSON.stringify({
      name: "Printed PDF"
    }));
  });

https.createServer(tlsOptions, app).listen(8443, function () {
  console.log("App HTTPS Started on PORT " + 8443);
  console.log("SSL cert location: " + keyLocation);
});