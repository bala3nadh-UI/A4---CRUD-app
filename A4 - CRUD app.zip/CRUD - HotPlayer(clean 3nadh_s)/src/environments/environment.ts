// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `angular-cli.json`.

const NODEJS_BASE_PATH = 'https://3nadh-Appv2-dev-nodejsproxy.3nadh-resorts.com/';
// const NODEJS_BASE_PATH = 'https://localhost:8443/';
/* const STABLE_PATH = "https://3nadh-Appv2-dev-cageapi-st3.3nadh-resorts.com/";
const PATRON_BASE_PATH = 'https://3nadh-Appv2-dev-patronmgtapi.3nadh-resorts.com/';
const ITADMIN_BASE_PATH = 'https://3nadh-Appv2-dev-itadminapi.3nadh-resorts.com/';
const LOYALTY_BASE_PATH = "https://3nadh-Appv2-dev-loyaltyapi.3nadh-resorts.com/";
const HotPlayerAPI_BASE_PATH = "https://3nadh-Appv2-dev-techrefresh-hotplayer-api.3nadh-resorts.com/"; */
const STABLE_PATH = "http://g2-proxy/";
const PATRON_BASE_PATH = 'http://techrefresh-patron-mgnt-api/';
const ITADMIN_BASE_PATH = 'http://techrefresh-itadmin-api/';
const LOYALTY_BASE_PATH = "http://techrefresh-loyalty-api/";
const HotPlayerAPI_BASE_PATH = "http://techrefresh-mobile-hotplayer-api/";
const NODEJS_STORE_PDF = "http://10.102.20.103:8810/api/";


export const environment = {
	version: "0.0.1",
	envName: "dev",
    production: false,
    OAuthEnable: true,
    serverPath: PATRON_BASE_PATH + "api/patron-mgnt/v1/",
    nodeBasePath: `${NODEJS_BASE_PATH}`,
    EmbedTokenPath: `${NODEJS_BASE_PATH}embedToken`,
    EmbedTokenWithUploadPath: NODEJS_BASE_PATH + "embedTokenWithUpload",
    LoginAPI: `${NODEJS_BASE_PATH}access`,
    LoyaltyAPI: LOYALTY_BASE_PATH+ "api/loyalty-mgmt/v1/",
    ItAdminAPI: ITADMIN_BASE_PATH+ "api/itadmin/v1/",
    EmployeesData:`${STABLE_PATH}api/cage/v1/actors/employeesData`,
    PatronMgmtAPIPath: `${PATRON_BASE_PATH}api/patron-mgnt/v1/`,
    MobileSignUpDummyURL_CheckPatronEligibility: "http://codvsgemwes01.1stApp.com:29291/3nadh-App2/RegistrationValidation/CheckPatronIdentification",
    MobileSignUpDummyURL_CheckPatronValidity:"http://codvsgemwes01.1stApp.com:29291/3nadh-App2/RegistrationValidation/CheckPatronValidity",
    ITAdminAPIPath: ITADMIN_BASE_PATH + "api/itadmin/v1/",
    HotPlayerAPI: HotPlayerAPI_BASE_PATH+ "api/mobile-hotplayer/v1/",
    savePDF: NODEJS_STORE_PDF + "uploadhtml"
};
