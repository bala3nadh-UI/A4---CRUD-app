declare module 'angular2-translator';
interface Window { nativeAPI: any;
MyFrameworkCall:any; angularComponentRef:any}
