import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { HttpOauth } from '../injectable/http-oauth';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/mergeMap';
import * as moment from 'moment';

@Injectable()
export class HotPlayerService {

  baseUrl = environment.HotPlayerAPI;

  constructor(private http: Http, private httpOauth: HttpOauth) { }

  getNonCodedHotPlayer(id: string) {

    //fake service call
     /*return this.http.get('assets/waste/document.json')
        .toPromise()
        .then(res => {
          return <model.HotCardPlayer> res.json()
      });*/
    //return this.http.get('assets/waste/document.json').map(res => {
    return this.http.get('/getAll').map(res => {      
      return res.json();
    }); 

   /*   return Observable.interval(500000).startWith(0).flatMap((i) => {
        console.log("flat Map");
        console.log(i);
        return this.http.get('assets/waste/document.json')
      }).map(res => {
              console.log("Map");
              console.log(res);
               return res.json();
          });  */          

      // service call
      /* id= '2017-03-01';
       const url = `${this.baseUrl}mobile/hotplayer/${id}`;
       const headers = new Headers({ 'Content-Type': 'application/json' });
        return this.httpOauth.get(url, { headers: headers }).map(res => {
           return res.json();
        }); */

      //service call - no authentication  // id= '2017-03-01';
     /*let sysDate = moment().format('YYYY-MM-DD');
       const url = `${this.baseUrl}mobile/hotplayer/${sysDate}`;
       const headers = new Headers({ 'Content-Type': 'application/json' });
        return this.httpOauth.get(url, { headers: headers }).map(res => {
           return res.json();
        });*/

      // Interval Observables
     /*  let sysDate = '2017-03-01';
      const url = `${this.baseUrl}mobile/hotplayer/${sysDate}`;
       const headers = new Headers({ 'Content-Type': 'application/json' });
       return Observable.interval(10000).startWith(0).flatMap((i) => this.http.get(url, { headers: headers })).map(res => {
               return res.json();
          }); */
  
                 
  }

  resolveRejectHotPlayer(requestObj) {
      console.log(requestObj);
       let sysDate = moment().format('YYYY-MM-DD');
      const url = `${this.baseUrl}mobile/hotplayer/event/${requestObj.patronNumber}/${requestObj.staffID}/${requestObj.action}/${sysDate}`;
       const headers = new Headers({ 'Content-Type': 'application/json' });
      /*return this.http.post(url,null,{headers:headers})
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });*/
      /*return this.http.get('assets/waste/document.json')
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });*/
      let url1 = "/deleteIt/" + requestObj.patronNumber;
      return this.http.get(url1)
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });
  }

  resolveAcceptHotPlayer(requestObj) {
      console.log(requestObj);
       let sysDate = moment().format('YYYY-MM-DD');
      const url = `${this.baseUrl}mobile/hotplayer/event/${requestObj.patronNumber}/${requestObj.staffID}/${requestObj.action}/${sysDate}`;
       const headers = new Headers({ 'Content-Type': 'application/json' });
      /*return this.http.post(url,null,{headers:headers})
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });*/
      /*return this.http.get('assets/waste/document.json')
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });*/
      let url1 = "/modifyIt/"+ requestObj.patronNumber + "/" + requestObj.checkin + "/" + requestObj.checkout;
      return this.http.get(url1)
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });
  }

  resolveAddHotPlayer(requestObj) {
      console.log(requestObj);
      let url1 = "/addIt/" + requestObj.patronNo + "/" + requestObj.patronLastName + "/" + requestObj.tier + "/" + requestObj.location + "/" + requestObj.theo + "/" + requestObj.lastRatingTime + "/" + requestObj.codedHost + "/" + requestObj.hostName + "/" + requestObj.booking[0].dept + "/" + requestObj.booking[0].checkin + "/" + requestObj.booking[0].checkout;
      return this.http.get(url1)
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });
  }

  resolveGetAllHotPlayers() {
      let url1 = "/getAll";
      return this.http.get(url1)
                  .toPromise()
                  .then(res => {
                    return res.json()
                  });
  }
}
