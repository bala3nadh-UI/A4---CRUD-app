import { Injectable,Input } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class LoadingService {

    public loadingFlag: Subject<boolean> = new Subject<boolean>();
   
    constructor() {

    }

    showLoading() {
        this.loadingFlag.next(true);
    }

    hideLoading() {
        this.loadingFlag.next(false);
    }

}
