import { Injectable,Input } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../environments/environment';
import { HttpOauth } from '../injectable/http-oauth';
import * as PatronComp from "../dataModels/models";

@Injectable()
export class ModifyCompService {

    baseUrl = environment.LoyaltyAPI;

    constructor(
        private http: HttpOauth,
    ) {
        
    }

    getModifyComp(id: string) {
        let path = `${this.baseUrl}mobile/exec/${id}`;
        return this.http.get(path).map(res => {
            let body = res['_body'];
            let result = body ? res.json() : body;
            return result;
        });
    }

    updateModifyComp(id: string, params: PatronComp.PatronComp) {
        let path = `${this.baseUrl}mobile/exec/${id}`;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        return this.http.put(path, JSON.stringify(params), { headers: headers }).map(res => {
            return res;
        });
    }
    

}
