import { Injectable,Input } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class LoginService {

    baseUrl = environment.LoginAPI;
    userInformation: any = null;

    constructor(
        private http: Http
    ) {
        
    }

    login(userName: string, passWord: string) {
        let path = this.baseUrl;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let params = {
            password: passWord,
            username: userName,
            station: "outlet1"
        };
        return this.http.post(path, JSON.stringify(params), { headers: headers }).map(res => {
            let result = res.json();
            this.setUserInformation(result);
            return result;
        });
    }

    setUserInformation(data) {
        if(data.isAuthenticated){
            this.userInformation = {
                id: data.permissionObj.user,
                name: data.userName
            };
        }
    }

    getUserInformation() {
        return this.userInformation;
    }

    clearUserInformation() {
        this.userInformation = null;
    }
    

}
