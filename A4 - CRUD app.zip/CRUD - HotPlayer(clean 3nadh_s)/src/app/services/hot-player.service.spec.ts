/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { HotPlayerService } from './hot-player.service';

describe('HotPlayerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HotPlayerService]
    });
  });

  it('should ...', inject([HotPlayerService], (service: HotPlayerService) => {
    expect(service).toBeTruthy();
  }));
});
