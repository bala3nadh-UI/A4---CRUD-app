import { Injectable, Input } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../environments/environment';
import { HttpOauth } from '../injectable/http-oauth';
import * as PatronComp from "../dataModels/models";

@Injectable()
export class EditGuestListService {

    baseUrl = environment.ItAdminAPI;

    constructor(
        private http: HttpOauth,
    ) {
        
    }

    getGuestType() {
        return new Promise<Array<any>>(
            resolve => {
                let categoryPath = `${this.baseUrl}category/all`;
                this.http.get(categoryPath).subscribe(res => {
                    let result = res.json().payload;
                    for(let item of result){
                        if(item.name.toUpperCase() == "EXECCOMPGUESTTYPE"){
                            let lookUpPath = `${this.baseUrl}lookup/categoryId/${item.id}`;
                            this.http.get(lookUpPath).subscribe(res => {
                                let arr = res.json().payload;
                                arr = arr.sort(function(a, b) {
                                    return a.displayOrder - b.displayOrder;
                                });
                                resolve(arr);
                            })
                        }
                    }
                });
            }
        );
    }

    getEmployee() {
        let employeesPath = environment.EmployeesData;
        return this.http.get(employeesPath).map(res => {
            let result = res.json();
            return result;
        })
    }

    getPatronAndCheck(patronId: string) {
        let path = `${environment.PatronMgmtAPIPath}mgnt/${patronId}`;
        return this.http.get(path).map(res => {
            let result = res.json();
            return result;
        })
    }

}
