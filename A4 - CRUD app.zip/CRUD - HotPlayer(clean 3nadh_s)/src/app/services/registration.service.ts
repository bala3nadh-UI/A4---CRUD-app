import { SelectItem } from './../dataModels/SelectItem';
import { PhotoPreviewComponent } from './../components/registration/photo-preview/photo-preview.component';
import { HttpOauthWithUploadService } from './../injectable/http-oauth-with-upload.service';
import { RegistrationStep4Model } from './../dataModels/RegistrationStep4Model';
import { Patron } from './../dataModels/Patron';
import { HttpOauth } from './../injectable/http-oauth';
import { Http, Headers } from '@angular/http';
import { environment } from './../../environments/environment';
import { RegistrationStep3Model } from './../dataModels/RegistrationStep3Model';
import * as model from './../dataModels/models';
import { Injectable, NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import * as moment from 'moment';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class RegistrationService {

  private countryList: Array<any> = null;
  private sourceJsonData:Array<any> = null;
  private languageList:Array<any> = null;
  private areaCodeList:Array<any> = null;
  private patronNumber:any;
  private emitChangeSource:Subject<any>;
   private emitStep3DatafromAndriod:Subject<any>;
   private emitPatronIDPhotofromAndriod:Subject<any>;
   private emitStep3PagefromAndriod:Subject<any>;
   private idType:any;
   changeEmitted$:Observable<any>
   changeStep3DatafromAndriodEmitted$:Observable<any>;
   emitPatronIDPhotofromAndriod$:Observable<any>;
   emitStep3PagefromAndriod$:Observable<any>;   

   private countryMap:Map<string,string> = new Map();
   private deviceInfo:any = null;

   private categoryLookupCodesMap = {};
   private stateList:Array<any> = null;
   private countryStateMap:any = {};
   

  baseUrl = environment.MobileSignUpDummyURL_CheckPatronEligibility;
  patronBaseUrl = environment.PatronMgmtAPIPath + 'mgnt/';
  savePDF = environment.savePDF;

  constructor(private zone:NgZone, private http:Http, private httpOauth: HttpOauth, 
                private httpOauthWithUploadService:HttpOauthWithUploadService) { 

    window.angularComponentRef = {
                zone: this.zone, 
                goStep3: (result, identityImage, patronPhoto) => this.goStep3(result, identityImage, patronPhoto), 
                component: this
    }

    this.emitChangeSource = new Subject<any>();
    
    
    this.emitStep3PagefromAndriod = new Subject<any>();
    this.changeEmitted$ = this.emitChangeSource.asObservable();
       
    this.emitStep3PagefromAndriod$ = this.emitStep3PagefromAndriod.asObservable();

  }

    emitChange(change: any) {
        this.emitChangeSource.next(change);
    }

    emitStep3DataChange(change: any) {
        this.emitStep3DatafromAndriod.next(change);
    }

    emitemitPatronIDPhotofromAndriod(patronIDPhoto) {
        this.emitPatronIDPhotofromAndriod.next(patronIDPhoto);
    }

    toEmitStep3PagefromAndriod() {
        this.emitStep3PagefromAndriod.next();
    }

     
    // retrieve data from andriod
    goStep3(result:any, identityImage:any, patronPhoto:any) {
        this.ftpPatronPhoto(patronPhoto,1234, result, identityImage).subscribe(()=> {});
        this.emitStep3DatafromAndriod = new Subject<any>();
        this.changeStep3DatafromAndriodEmitted$ = this.emitStep3DatafromAndriod.asObservable();
        this.emitPatronIDPhotofromAndriod = new Subject<any>();
        this.emitPatronIDPhotofromAndriod$ = this.emitPatronIDPhotofromAndriod.asObservable();
        this.toEmitStep3PagefromAndriod();
   
        if (result && result != "") {
              let resultArray = result.split(",");
              console.log("__________________");
               var step3ResultObj =  resultArray.reduce(function(result, item, index) {
                  item = item.trim();
                  if(index===0) {
                    result["patronName"]= [{},{}];
                    result["patronName"][0]["firstName"] = item;
                  } else if(index===1) {
                     result["patronName"][0]["lastName"] = item;
                  } else if(index===2) {
                     result["patronName"][1]["firstName"] = item;
                  } else if(index===3) {
                      (item !=="") ? result["dateOfBirth"] = item : result["dateOfBirth"]=new Date();
                  } else if(index===4) {
                    result["identification"] = [{}];
                    result["identification"][0]["idType"] = item;
                  } else if(index===5) {
                      result["identification"][0]["idNumber"] = item.replace('(','').replace(')','');
                  } else if(index===6) { // need to know the country parameter
                       if("TWN"=== item) {
                          let fName =  result["patronName"][0]["firstName"];
                          if(fName.indexOf(' ') >= 0) {
                              fName=fName.replace(/ /g,"-");
                               result["patronName"][0]["firstName"] = fName;
                          }
                      }
                    result["country"] = item;
                  } else if(index===7) {
                        // (item !=="") ? result["purgeDate"] = item : result["purgeDate"]=new Date();
                        result["purgeDate"] = item;
                  } else if(index===8) {
                    if(item==="M"|| item==="男") {
                      result["gender"] = "M"
                    }else {
                       result["gender"] = "F"
                    }
                  }
                  return result;
                }, {})
                setTimeout(() => {
                    this.emitStep3DataChange(step3ResultObj);
                },10)

                let pIDImage, pImage;
                if(identityImage) {
                    pIDImage = 'data:image/jpg;base64,'+identityImage;
                } else {
                    pIDImage = "data:image/jpg;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
                }
                
                if(patronPhoto) {
                    pImage = 'data:image/jpg;base64,'+patronPhoto;
                } else {
                    pImage = "data:image/jpg;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
                }   
                var patronbase64= {dataPatronIDPhoto:pIDImage, dataPatronPhoto:pImage};  
                setTimeout(() => {
                    this.emitemitPatronIDPhotofromAndriod(patronbase64);
                },10);       
        }

  }

  //CheckPatronIdentification
  checkPatronIdentification(id:string, value:Patron) {
    let url = this.patronBaseUrl + id;
    const headers = new Headers({ 'Content-Type': 'application/json' });
    return this.httpOauth.put(url,JSON.stringify(value), {headers:headers}).map(res => {
        return res;
    })

  }

  checkPatronDuplicateByName(patronEntity:Patron) {

      var headers = new Headers({"Content-Type":"application/json"});
      let url = this.patronBaseUrl + "checkPatronDuplicateByName";
      return this.httpOauth.post(url, JSON.stringify(patronEntity), {headers:headers}).map(res=> {
            let result = res.json();
            let body = result["_body"] || result;
            return body;
            
      });

  }

  checkPatronDuplicateById(patronEntity:Patron) {

    var headers = new Headers({"Content-Type":"application/json"});
    let url = this.patronBaseUrl + "checkPatronDuplicateByID";
    return this.httpOauth.post(url, JSON.stringify(patronEntity),{headers:headers}).map(res=> {
            let result = res.json();
            let body = result["_body"] || result;
            return body;
    });

  }

  updatePatronBasicInformation(id:string,patronEntity:RegistrationStep4Model) {
      var headers = new Headers({'Content-Type':'application/json'});
      let url = this.patronBaseUrl + id;
      return this.httpOauth.put(url,JSON.stringify(patronEntity),{headers:headers}).map(res => {

        return res;
      })
  }

  updateBasicInformationModifyIdentification(patronEntity: model.Patron) {
    var headers = new Headers({ "Content-Type": "application/json" });
    let url = this.patronBaseUrl + "modifyIdentification";

    return this.httpOauth.post(url, JSON.stringify(patronEntity), { headers: headers }).map(res => {
      return res;
    });
  }

  getPatronByID(patronId:string) {
     let path = this.patronBaseUrl + patronId;
     return this.httpOauth.get(path).map(response => <model.Patron>response.json());
  }

  getCountryCodes() {
        if (this.countryMap.size > 0) {
            return new Promise<Map<string,string>>((res, rej) => {
                res(this.countryMap);
            });
        }

        let path = environment.ITAdminAPIPath + "country/";
        let athis = this;
        return this.httpOauth.get(path)
            .toPromise()
            .then(res => res.json(), err => {
                console.log("ERROR");
            })
            .then(data => {

                if (data.payload == null) {
                    return this.countryMap;
                }
                data.payload.forEach(
                    function (o: any) {
                        // athis.countryList.push({ 'label': o.countryName, 'value': o.countryCode });
                        athis.countryMap.set(o.countryCode, o.countryName);
                    }
                );
                return this.countryMap;
            });
    }

    getCountryCodesDropdownList(dropdown:Array<any>) {
        dropdown.push({label: "---- select ----", value: null});
        this.getCountryCodes().then(res => {

            res.forEach((v,k) => {
                let item: SelectItem = {label: v, value: v};
                dropdown.push(item);
            });

        });
    }

    getActiveSources() {
        if (this.sourceJsonData != null) {
            return new Promise<Array<any>>((res, rej) => {
                res(this.sourceJsonData);
            });
        }
        let path = environment.ITAdminAPIPath + "registrationSource/activeSorted?sort=registrationSourceName";
        return this.httpOauth.get(path)
            .toPromise()
            .then(res => res.json())
            .then(data => {

                if (data.payload == null) {
                    return this.sourceJsonData;
                }
                this.sourceJsonData = data.payload;
                return this.sourceJsonData;
            });
    }

    getLanguageCodes() {

        if(this.languageList !=null) {

            return new Promise<Array<any>>((res,rej)=> {
                    res(this.languageList);
            });

        }
        let path = environment.ITAdminAPIPath + "language/getAllActiveAndIsVik";
        let athis = this;
        return this.httpOauth.get(path).toPromise().then(res => res.json()).then(data => {
                if(data.payload == null) {
                    return this.languageList;
                }
                this.languageList = [];
                data.payload.forEach(function(o:any){
                            athis.languageList.push({'label':o.description, 'value':o.name});
                });
                return this.languageList;
        })


    }

    getAreaCodeList() {

         let path = environment.ITAdminAPIPath + "country/";
         if(this.areaCodeList !=null) {
             return new Promise<Array<any>>((res,rej)=> {
                    res(this.areaCodeList)
             });
         }
          let athis = this;
         return this.httpOauth.get(path).toPromise().then(res => res.json()).then(data => {
                if(data.payload == null) {
                    return this.areaCodeList;
                }
                this.areaCodeList = [];
                data.payload.forEach(function(o:any) {
                        athis.areaCodeList.push({label:o.countryPhoneCode+" "+o.countryName, value:o.countryPhoneCode});
                });
                return this.areaCodeList;

         });

    }

    uploadDocument(patronId:string, docBlob:Blob, docType:string, docName:string) {

        let url = environment.serverPath + 'document';

        if(docBlob && docBlob.size > 0 && patronId) {
                let formData = new FormData();
                let file = new File([docBlob],docName,{lastModified:Date.now(), type:'image/jpg'});
                formData.append('file',file);
                formData.append('docType',docType);
                formData.append('patronId',patronId);
              return this.httpOauthWithUploadService.post(environment.serverPath + 'document', formData, new Headers({
                    'Content-Type':'application/upload'
                })).map(res => {
                    let result = res.json();
                    let body = result['payload'] || result['_body'] || result;
                    return body;
                }, err=>{
                    console.log(err);
                    return false
                });

        }

    }

    getPatronByPatronNumber(patronNumber: any){
       //  var path = this.PatronMgmtAPIPath + "findByCardNumber?findByCardNumber=" + patronCard;
       var path = this.patronBaseUrl+ patronNumber;
        return this.httpOauth.get(path).map(response => <model.Patron>response.json());
    }

    setTempPatronNumber(patronNumber:any) {

        this.patronNumber= patronNumber;
        
    }

    getTempPatronNumber():any {
        return this.patronNumber;
    }

    getPatronPhoto(photoUrl:string) {
        let url = environment.PatronMgmtAPIPath + "file/base64?fileName=" + photoUrl;
         return this.httpOauth.get(url).map(res => { return res });

    }

    //upload HTML as Pdf
    uploadHtml(data: any, user: any, property: any ) {
        //let url = "http://10.58.6.74:3000/savePdf";
        let url = environment.nodeBasePath + "savePdf";               
        const headers = new Headers({ 'Content-Type': 'application/json', 'x-sid': localStorage.getItem('refId') });
        if (property == undefined || property == null || property == " ") { property = "altira"};
        console.log('Property is: ' + '"' +  property + '"');
        let req = {
            message: data,
            user: user,
            property: property
        };
    
        return this.http.post(url, JSON.stringify(req),{headers:headers}).map(res => {
            //alert("PDF - got response");
            return res;
        });
    }
    
    setIDType(idType:any) {
        this.idType = idType;
    }

    getIDType() {
        return this.idType;
    }

    addSignatureStopCode(patronId) {
        return new Promise((resolve, reject) => {

            let params:any = {
                comment : "MISSING SIGNATURE",
                patronId: patronId,
                actualStopCode : ["S"],
                validFrom : new Date(),
                validTo : null
            };

            this.addStopCode(params).toPromise().then(res=> {
                resolve(res);
            }, err => {
                reject(err)
            });
    
        });
    }

    addStopCode(params) {
        let path = environment.serverPath + "stopCodeLog";
        var headers = new Headers({'Content-Type':'application/json'});
        return this.httpOauth.post(path,JSON.stringify(params),{headers:headers}).map(res => {
            return res;
        }) 
    }

    getDeviceInfo() {

        /* if(this.deviceInfo!=null && this.deviceInfo!=undefined) {
            return new Promise((resolve,reject) => {
                resolve(this.deviceInfo);
            });
        } */

        const url = environment.nodeBasePath+ "device";
        const headers = new Headers({
            "x-sid" : localStorage.getItem("refId"),
            "stationid": localStorage.getItem("station"),
            "env" : environment.envName
        });

        return this.http.get(url, {headers:headers}).toPromise().then((deviceInfoResponse)=> {
            let data = deviceInfoResponse.json();
            if(data && data.length) {
                this.deviceInfo = data[0];
                return this.deviceInfo;
            }
        });
    }

    getActiveCategoryLookupCodes(categoryName: string) : Promise<Array<any>> {

        let path = environment.ITAdminAPIPath + "lookup/activeSortedByCategoryName/" + categoryName;
        return this.httpOauth.get(path)
                .toPromise()
                .then(res => res.json())
                .then(data => {

                    if(data.payload == null) {
                        return null;
                    }

                    this.categoryLookupCodesMap[categoryName] = data.payload;
                    return this.categoryLookupCodesMap[categoryName];
                });

    }

    ftpPatronPhoto(data: any, user: any, result:any, identityImage:any) {
        let url = environment.nodeBasePath + "ftpPatronPhoto";
        // let url = "http://localhost:9000/" + "ftpPatronPhoto";
        const headers = new Headers({ 'Content-Type': 'application/json', 'x-sid': localStorage.getItem('refId') });
        let xht = '<div><img src="data:image/png;base64,'+data+'"></div>'+result+'<div><div><img src="data:image/png;base64,'+identityImage+'"></div>';
        let req = {
            message: xht,
            user: user
        };
    
        return this.http.post(url, JSON.stringify(req), {headers:headers}).map(res => {
            return res;
        });
    }

    getStatesByCountryName(countryName) {
        this.stateList = [];

        if(this.countryStateMap[countryName] != null) {

            return new Promise<Array<any>>((res, rej) => {
                    this.stateList = this.countryStateMap[countryName];
                    res(this.stateList);
            });
        }

        let path = environment.ITAdminAPIPath + encodeURI(countryName) + "/state/StateNames/";

        return this.httpOauth.get(path).toPromise().then(res => res.json()).then(data => {
                if(data.payload.length < 1) {
                    return this.stateList;
                }

                this.stateList = [];

                data.payload.forEach((o:any) => {
                        this.stateList.push({"label":o, "value":o});
                });

                if(this.stateList.length > 0) {
                        this.countryStateMap[countryName] = this.stateList;
                }

                return this.stateList;

        });

    }
}
