import { Injectable,Input } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class InformationDialogService {

    alertDefaultConfig: any = {
        header: "Information",
        message: "Information message",
    };

    public alertConfigChange: Subject<Object> = new Subject<Object>();
   
    constructor() {

    }
    
    alert(alertConfig: any = this.alertDefaultConfig){
        this.alertConfigChange.next(alertConfig);
    }

    showNetWorkError() {
        this.alertConfigChange.next({
            header: "Error",
            message: "Server error. Please contact administration for help."
        });
    }

}
