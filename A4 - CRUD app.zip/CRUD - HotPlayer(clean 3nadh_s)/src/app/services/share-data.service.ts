import { Injectable,Input } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { RegistrationStep3Model}  from  "../dataModels/models";
import { Router } from '@angular/router';
import { Http, Headers } from '@angular/http';

@Injectable()
export class ShareDataService {

    dataArray: Array<RegistrationStep3Model> = new Array();
    signImg: string;
    tremsImg1: string;
    tremsImg2: string;
    step5Img: string;
    print: boolean = true;
    successMsg: string;
	isPdfErr: boolean = false;
    appDate: string;
    step5Html: string;
    step5Title: string;
    step5PrefLang: string;
    step5SendSms: boolean;
    step5DirectEmail: string;
    step5SendEmail: boolean;
    step5IdType: string;
    deviceInfo: any;
    completeHtml: string;

    step3DataObj:any;
    patronIDPhotoAsBlob:any;
    patronPhotoAsBlob:any;
    step4DataObj:any;
    patronIDPhotoAsBlobImage:any;
    patronPhotoAsBlobImage:any;
    step1DataObj:any;


    constructor(private http: Http) { }

    insertData(data: RegistrationStep3Model){
        this.dataArray = new Array();
        this.dataArray.push(data);
    }

    insertSignImg(data: string){
        this.signImg = "";
        this.signImg = data;
    }

    insertTermsImg(data1: string, data2: string){
        this.tremsImg1 = "";
        this.tremsImg1 = data1;
        this.tremsImg2 = "";
        this.tremsImg2 = data2;
    }
    
    insertstep5Img(data: string){
        this.step5Img = "";
        this.step5Img = data;
    }
        
    insertCompHtml(data: string){
        this.completeHtml = "";
        this.completeHtml = data;
    }

    insertstep5Html(data: string, title: string, prefLang: string, sendSms: boolean, directEmail: string, sendEmail: boolean, idType: string, appDate: string){
        this.step5Html = "";
        this.step5Html = data;
        this.step5Title = "";
        this.step5Title = title;
        this.step5PrefLang = "";
        this.step5PrefLang = prefLang;
        //this.step5SendSms = "";
        this.step5SendSms = sendSms;
        this.step5DirectEmail = "";
        this.step5DirectEmail = directEmail;
        //this.step5SendEmail = "";
        this.step5SendEmail = sendEmail;
        this.step5IdType = "";
        this.step5IdType = idType;
        this.appDate = "";
        this.appDate = appDate;
    }

    insertPrint(data: boolean){
        this.print = data;
    }

    insertSuccess(data: string){
        this.successMsg = data;
    }

	insertPdfErr(data: boolean){
        this.isPdfErr = data;
    }

    setStep3DataObj(dataObj) {
        this.step3DataObj = dataObj;
    }

   getStep3DataObj() {
       return this.step3DataObj;
   }

   setPatronIDPhotoAsBlob(dataObj) {
        this.patronIDPhotoAsBlob =dataObj; 
   }

   getPatronIDPhotoAsBlob() {
       return this.patronIDPhotoAsBlob;
   }

   setPatronPhotoAsBlob(dataObj) {
        this.patronPhotoAsBlob = dataObj;
   }

   getPatronPhotoAsBlob() {
       return this.patronPhotoAsBlob;
   }

   setStep4DataObj(dataObj) {
        this.step4DataObj = dataObj;
   }

   getStep4DataObj() {
       return this.step4DataObj;
   }

   setPatronIDPhotoAsBlobImage(dataObj) {
        this.patronIDPhotoAsBlobImage = dataObj;
   }

   getPatronIDPhotoAsBlobImage() {
       return this.patronIDPhotoAsBlobImage;
   }

   setPatronPhotoAsBlobImage(dataObj) {
        this.patronPhotoAsBlobImage = dataObj;
   }

   getPatronPhotoAsBlobImage() {
       return this.patronPhotoAsBlobImage;
   }

   setStep1DataObj(dataObj) {
       this.step1DataObj = dataObj;
   }

   getStep1DataObj() {
       return this.step1DataObj;
   }

   setDeviceInfo(deviceInfo: string) {
       this.deviceInfo = " ";
       this.deviceInfo = deviceInfo;
   }

   getDeviceInfo() {
       return this.deviceInfo;
   }
}
