import { environment } from './../../environments/environment';

import { Http } from '@angular/http';
import { HttpOauth } from './http-oauth';
import { Injectable } from '@angular/core';

@Injectable()
export class HttpOauthWithUploadService extends HttpOauth {

  constructor(http:Http) { 
    super(http);
    this.custom_proxy_url = environment.EmbedTokenWithUploadPath;

  }

}
