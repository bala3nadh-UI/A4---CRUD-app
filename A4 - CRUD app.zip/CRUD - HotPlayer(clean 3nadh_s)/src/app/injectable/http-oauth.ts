import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptionsArgs, Response } from '@angular/http';
import { environment } from '../../environments/environment'
import { Observable } from 'rxjs/Observable';

@Injectable()
export class HttpOauth {

    custom_proxy_url: string;

    constructor(private http: Http) { this.custom_proxy_url = environment.EmbedTokenPath; }

    AppendHeader(headers: Headers, url: string) {
        let _headers;
        if (!headers) {
            _headers = new Headers();
        } else {
            _headers = headers
        }
        _headers.set('end-point-domain', url);
        _headers.set('x-sid', localStorage.getItem('refId'));
        _headers.set("stationid", localStorage.getItem("station"));
        return _headers;
    }


    get(url: string, options: RequestOptionsArgs = {}): Observable<Response> {
        if (environment.OAuthEnable) {
            options.headers = this.AppendHeader(options.headers, url);
            return this.http.get(this.custom_proxy_url, options);

        } else {
            return this.http.get(url, options);
        }
    }
    post(url: string, body: any, options: RequestOptionsArgs = {}): Observable<Response> {
        if (environment.OAuthEnable) {
            options.headers = this.AppendHeader(options.headers, url);
            return this.http.post(this.custom_proxy_url, body, options);
        } else {
            return this.http.post(url, body, options);
        }
    }

    put(url: string, body: any, options: RequestOptionsArgs = {}): Observable<Response> {
        if (environment.OAuthEnable) {
            options.headers = this.AppendHeader(options.headers, url);
            return this.http.put(this.custom_proxy_url, body, options);
        } else {
            return this.http.put(url, body, options);
        }
    }
    delete(url: string, options: RequestOptionsArgs = {}): Observable<Response> {
        if (environment.OAuthEnable) {
            options.headers = this.AppendHeader(options.headers, url);
            return this.http.delete(this.custom_proxy_url, options);
        } else {
            return this.http.delete(url, options);
        }
    }
    patch(url: string, body: any, options: RequestOptionsArgs = {}): Observable<Response> {
        if (environment.OAuthEnable) {
            options.headers = this.AppendHeader(options.headers, url);
            return this.http.patch(this.custom_proxy_url, body, options);
        } else {
            return this.http.patch(url, body, options);
        }
    }
}