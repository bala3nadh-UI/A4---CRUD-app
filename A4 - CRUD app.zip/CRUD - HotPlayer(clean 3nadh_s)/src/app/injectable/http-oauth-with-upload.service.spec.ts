/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { HttpOauthWithUploadService } from './http-oauth-with-upload.service';

describe('HttpOauthWithUploadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpOauthWithUploadService]
    });
  });

  it('should ...', inject([HttpOauthWithUploadService], (service: HttpOauthWithUploadService) => {
    expect(service).toBeTruthy();
  }));
});
