import { HttpOauthWithUploadService } from './injectable/http-oauth-with-upload.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { DatePipe, CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { AppRoutingModule }     from './app-routing.module';

import {TranslateModule} from "ng2-translate";
import './rxjs-extensions';
import {Ng2Webstorage} from 'ng2-webstorage';

/*ImportComponents*/
import { LoginPageComponent } from './components/login/login.component';
import { ModifyCompPageComponent } from './components/modify-comp/modify-comp.component';
import { ModifyCompEditGuestListPageComponent } from './components/modify-comp/edit-guest-list/edit-guest-list.component';
import { InformationDialogComponent } from './components/information-dialog/information-dialog.component';
import { LoadingComponent } from './components/loading/loading.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { RegisterStep1Component } from './components/registration/register-step1/register-step1.component';
import { RegisterStep2Component } from './components/registration/register-step2/register-step2.component';
import { RegisterStep3Component } from './components/registration/register-step3/register-step3.component';
import { RegisterStep4Component } from './components/registration/register-step4/register-step4.component';
import { RegisterStep5Component } from './components/registration/register-step5/register-step5.component';
import { PhotoPreviewComponent } from './components/registration/photo-preview/photo-preview.component';
import { TermsConditionsComponent } from './components/registration/terms-conditions/terms-conditions.component';
import { SignaturePadComponent } from './components/registration/signature-pad/signature-pad.component';
import { ConfirmComponent } from './components/confirm/confirm.component';

import { MenuModule, ContextMenuModule, DropdownModule, TabViewModule, TabMenuModule, CheckboxModule, MultiSelectModule, RadioButtonModule, InputMaskModule, CalendarModule, PickListModule, OverlayPanelModule, DataListModule, PanelModule } from 'primeng/primeng';

import { DataTableModule, SharedModule, DialogModule, ConfirmDialogModule} from 'primeng/primeng';

/*ImportServices*/
import { LoginService } from './services/login.service';
import { ModifyCompService } from './services/modify-comp.service';
import { InformationDialogService } from './services/information-dialog.service';
import { LoadingService } from './services/loading.service';
import { EditGuestListService } from './services/edit-guest-list.service';
import { ShareDataService } from './services/share-data.service';
import { RegistrationService } from './services/registration.service';
import { HttpOauth } from './injectable/http-oauth';
import * as moment from 'moment';
import { DuplicateAccountComponent } from './components/registration/duplicate-account/duplicate-account.component';
import {HotplayerComponent} from './components/hotplayer/hotplayer.component';
import {HeaderComponent} from './components/header/header.component';
import { HotPlayerService } from './services/hot-player.service';
import {ConfirmationService} from 'primeng/primeng';
import { StringpaddingPipe } from './pipe/stringpadding.pipe';
import { MomentModule } from 'angular2-moment';
import { RegisterErrorhandlerComponent } from './components/registration/register-errorhandler/register-errorhandler.component';




@NgModule({
  declarations: [
    AppComponent,
    InformationDialogComponent,
    LoadingComponent,
    LoginPageComponent,
    ModifyCompPageComponent,
    ModifyCompEditGuestListPageComponent,
    DuplicateAccountComponent,
    RegistrationComponent,
    RegisterStep1Component,
    RegisterStep2Component,
    RegisterStep3Component,
    RegisterStep4Component,
    RegisterStep5Component,
    PhotoPreviewComponent, 
    RegisterErrorhandlerComponent,
    TermsConditionsComponent,
    SignaturePadComponent, 
    ConfirmComponent,  
    HotplayerComponent,
    HeaderComponent,
    StringpaddingPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    CommonModule,
    TranslateModule.forRoot(),
    Ng2Webstorage,
    ReactiveFormsModule,
    CalendarModule,
    DropdownModule,
    RadioButtonModule,
    CheckboxModule,
    DataTableModule,
    DialogModule,
    ConfirmDialogModule,
    MomentModule
  ],
  providers: [
    InformationDialogService,
    LoadingService,
    LoginService,
    ModifyCompService,
    HttpOauth,
    EditGuestListService,
    RegistrationService,
    ShareDataService,
    HttpOauthWithUploadService,
    HotPlayerService,
    ConfirmationService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
