// member info

export var MEMBERINFO = {
     ID: 'no-id',
     INPUT_PIN:'no-input-pin',
}
