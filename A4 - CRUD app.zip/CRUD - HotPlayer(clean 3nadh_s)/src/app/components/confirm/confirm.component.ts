import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalLangConstVariable, GlobalLangVariable } from '../../globals';
import { LoginService } from '../../services/login.service';
import { InformationDialogService } from '../../services/information-dialog.service';

@Component({
  selector: 'app-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css']
})
export class ConfirmComponent implements OnInit {
  userInformation: any;

  constructor(
    private loginService: LoginService,
    private router: Router,
    private informationDialogService: InformationDialogService,
  ) { }

  ngOnInit() {
     /* setTimeout((router: Router) => {
        this.router.navigate(['AppLogin']);
    }, 900000); */ //time out after 15 mins

     this.userInformation = this.loginService.getUserInformation();
        if(this.userInformation){

        }else{
            this.logOut();
        }
  }

  logOut() {
    this.loginService.clearUserInformation();
    localStorage.clear();
    this.router.navigate(["AppLogin"]);
  }

  printSlips() {
		let printContents, popupWin;
		printContents = document.getElementById('printableArea').innerHTML;
		popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
		popupWin.document.open();
		popupWin.document.write(`
			<html>
			<head>
				<title>Print tab</title>
				<style>
					/* RESET */
					a,abbr,acronym,address,applet,article,aside,audio,b,big,blockquote,body,canvas,caption,center,cite,code,dd,del,details,dfn,div,dl,dt,em,embed,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,output,p,pre,q,ruby,s,samp,section,small,span,strike,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,tt,u,ul,var,video{margin:0;padding:0;border:0;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}table{border-collapse:collapse;border-spacing:0}

					/* Slip CSS */
					.couponSlipsEditor{position:relative;margin:0 auto;width:280px;background-color:#fff;font-family: Arial, Helvetica, "微軟正黑體", "Microsoft JhengHei", "Heiti TC", "LiHei Pro", "新細明體", PMingLiU, sans-serif;font-size: 12px;line-height: 1.3em;}.couponSlipsEditor .couponSection{position:relative;min-height:30px;font-size:12px;line-height:1.3em}.couponSlipsEditor .slipSection{padding:10px;border-bottom:1px solid #000}.couponSlipsEditor .couponSection.last .slipSection{border-bottom:0}.couponSlipsEditor .barcode{display:block;width:250px;margin:20px auto}.couponSlipsEditor .logo{display:block;width:150px;margin:10px auto}.couponSlipsEditor .couponHeader h1{font-weight:700;font-size:14px;line-height:1.3em;text-align:center;margin:0 0 5px}.couponSlipsEditor .couponHeader h2{font-weight:700;font-size:14px;line-height:1.3em;text-align:center;margin:0 0 10px}.couponSlipsEditor .couponHeader p{font-weight:700;font-size:12px;line-height:1.3em;text-align:center;margin:0 0 5px}.couponSlipsEditor .couponDate table,.couponSlipsEditor .patronSign table{width:100%}.couponSlipsEditor .signatureBox{height:50px}.couponSlipsEditor .contenteditable[contenteditable=true]{border:0}.couponSlipsEditor .staffSign p{font-size:12px;line-height:1.3em}.couponSlipsEditor .editorControl{position:absolute;top:0;width:210px;padding:0 10px}.couponSlipsEditor .editorControl.left{right:100%;text-align:right}.couponSlipsEditor .editorControl.right{left:100%;text-align:left}.couponSlipsEditor .contenteditable{width:100%;display:block;line-height:1.2em;padding:5px;min-height:100px;border:1px solid #fff;box-sizing:border-box;word-break: break-all;}.couponSlipsEditor .contenteditable.aRight{text-align:right}.couponSlipsEditor .contenteditable.aLeft{text-align:left}.couponSlipsEditor .contenteditable.aCenter{text-align:center}.couponSlipsEditor .contenteditable.fontArial{font-family:Arial, Helvetica, "微軟正黑體", "Microsoft JhengHei", "Heiti TC", "LiHei Pro", "新細明體", PMingLiU, sans-serif}.couponSlipsEditor .contenteditable.fontCalibri{font-family:Calibri,Candara,Segoe,Segoe UI,Optima,Arial, Helvetica, "微軟正黑體", "Microsoft JhengHei", "Heiti TC", "LiHei Pro", "新細明體", PMingLiU, sans-serif}.couponSlipsEditor .contenteditable.fontSize8{font-size:8px}.couponSlipsEditor .contenteditable.fontSize9{font-size:9px}.couponSlipsEditor .contenteditable.fontSize10{font-size:10px}.couponSlipsEditor .contenteditable.fontSize11{font-size:11px}.couponSlipsEditor .contenteditable.fontSize12{font-size:12px}.couponSlipsEditor .contenteditable.fontSize14{font-size:14px}.couponSlipsEditor .contenteditable.fontSize16{font-size:16px}.couponSlipsEditor .contenteditable.fontSize18{font-size:18px}.couponSlipsEditor .contenteditable.fontSize20{font-size:20px}.couponSlipsEditor .contenteditable.fontSize22{font-size:22px}.couponSlipsEditor .contenteditable.fontSize24{font-size:24px}.couponSlipsEditor .contenteditable.fontSize26{font-size:26px}.couponSlipsEditor .contenteditable.fontSize28{font-size:28px}.couponSlipsEditor .contenteditable.fontSize36{font-size:36px}.couponSlipsEditor .contenteditable.fontSize48{font-size:48px}.couponSlipsEditor .contenteditable.fontSize72{font-size:72px}.couponSlipsEditor .displayUploadImg{max-width: 80%;margin: 0 auto;display: block;}.editorControl{display: none;}
				</style>
			</head>
			<body onload="window.print();window.close()">${printContents}</body>
			</html>`
		);
		popupWin.document.close();
		// window.print();
	}

}

