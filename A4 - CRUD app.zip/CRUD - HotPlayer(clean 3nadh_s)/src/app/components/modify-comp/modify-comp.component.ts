import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalLangConstVariable, GlobalLangVariable } from '../../globals';
import { LoginService } from '../../services/login.service';
import { InformationDialogService } from '../../services/information-dialog.service';
import { ModifyCompService } from '../../services/modify-comp.service';
import { LoadingService } from '../../services/loading.service';
import * as PatronComp from "../../dataModels/models";

@Component({
    selector: 'app-modify-comp',
    templateUrl: './modify-comp.component.html',
    styleUrls: ['./modify-comp.component.css']
})
export class ModifyCompPageComponent implements OnInit {

    showDialog: boolean = false;
    compData: PatronComp.PatronComp = {};
    userInformation: any;
    submitFlag: boolean = false;
    noDataFlag: boolean = true;
    showNoCache: any = {
        noOfBusinessGuest: 0,
        noOfEmployee: 0,
        noOfGovtGuest: 0,
        noOfPatron: 0,
        noOfNgPatrons: 0
    }

    constructor(
        private loginService: LoginService,
        private router: Router,
        private informationDialogService: InformationDialogService,
        private modifyCompService: ModifyCompService,
        private loadingService: LoadingService,
    ) {

    }

    ngOnInit() {
        this.userInformation = this.loginService.getUserInformation();
        if(this.userInformation){
            this.refreshPage();
        }else{
            this.logOut();
        }
    }

    showEditGuestList() {
        this.showDialog = true;
    }

    computeGuestTypeNum(list: Array<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>) {
        this.showNoCache = {
            noOfBusinessGuest: this.compData.noOfBusinessGuest,
            noOfEmployee: this.compData.noOfEmployee,
            noOfGovtGuest: this.compData.noOfGovtGuest,
            noOfPatron: this.compData.noOfPatron,
            noOfNgPatrons: this.compData.noOfNgPatrons
        };

        for(let item of list){
            switch(item.guestType){
                case "EGTB": this.showNoCache.noOfBusinessGuest ++;
                    break;
                case "EGTE": this.showNoCache.noOfEmployee ++;
                    break;
                case "EGTG": this.showNoCache.noOfGovtGuest ++;
                    break;
                case "EGTP": this.showNoCache.noOfPatron ++;
                    break;
                default: this.showNoCache.noOfNgPatrons ++;
                    break;
            }
        }
    }

    getGuestList(list: Array<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>) {
        this.compData.patronCompGuests = list;
        this.computeGuestTypeNum(list);
    }

    onSubmit() {
        this.submitFlag = true;
        if(!this.compData.justification || !this.compData.patronCompGuests || !this.compData.patronCompGuests.length){
            return;
        } else {
            this.loadingService.showLoading();
            this.modifyCompService.updateModifyComp(this.userInformation.id, this.compData).subscribe(data => {
                this.loadingService.hideLoading();
                if(data["_body"] == "Success") {
                    this.logOut();
                }
            }, err => {
                this.loadingService.hideLoading();
                this.informationDialogService.showNetWorkError();
            })
        }
    }

    refreshPage() {
        this.loadingService.showLoading();
        this.submitFlag = false;
        this.modifyCompService.getModifyComp(this.userInformation.id).subscribe(data => {
            this.loadingService.hideLoading();
            if(data){
                this.compData = data;
                this.noDataFlag = false;
                this.computeGuestTypeNum(this.compData.patronCompGuests);
            }
        }, err => {
            this.loadingService.hideLoading();
            this.informationDialogService.showNetWorkError();
            this.noDataFlag = true;
        })
    }

    logOut() {
        this.loginService.clearUserInformation();
        localStorage.clear();
        this.router.navigate(["AppLogin"]);
    }

}
