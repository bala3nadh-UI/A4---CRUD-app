import { Component, OnInit, Output, Input, EventEmitter, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EditGuestListService } from '../../../services/edit-guest-list.service';
import { InformationDialogService } from '../../../services/information-dialog.service';
import { LoginService } from '../../../services/login.service';
import * as PatronComp from "../../../dataModels/models";

declare var $: any;

@Component({
    selector: 'app-modify-comp-edit-guest-list',
    templateUrl: './edit-guest-list.component.html',
    styleUrls: ['./edit-guest-list.component.css']
})
export class ModifyCompEditGuestListPageComponent implements OnInit {

    @Input() isShow: boolean = false;
    @Input() compGuestList: Array<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>;
    @Output() isShowChange: EventEmitter<boolean> = new EventEmitter;
    @Output() finishEdit: EventEmitter<Array<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>> = new EventEmitter;

    guestList: Array<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests> = [];
    guestTypeList: Array<any>;
    emoloyeeList: Array<any>;
    governmentCompanyList: Array<string>;
    governmentCompany: any = {
        isOnlyRead: false,
        isShow: false
    };
    nameError: string;
    companyError: string;
    currentItem: PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests = {
        guestType: "",
        guestName: "",
        guestCompany: "",
    };
    guestCodeTransfromValue: any = {};

    constructor(
        private router: Router,
        private editGuestListService: EditGuestListService,
        private informationDialogService: InformationDialogService,
        private loginService: LoginService,
    ) {
        
    }

    ngOnChanges(change) {
        if (change.hasOwnProperty("isShow") && change.isShow.currentValue) {
            $('#popup-guest-grid').modal('show');
            if(this.compGuestList){
                this.guestList = this.compGuestList;
            }
        }
    }

    ngOnInit() {
        $('#popup-guest-grid').on('hidden.bs.modal', e => {
            this.closeDialog();
        })
        let information = this.loginService.getUserInformation();
        if(information){
            this.getGuestTypeList();
            this.getEmoloyeeList();
            this.getGovernmentCompanyList();
        }
    }

    getGuestTypeList() {
        this.editGuestListService.getGuestType().then(res => {
            this.guestTypeList = res;
            for(let item of this.guestTypeList){
                this.guestCodeTransfromValue[item.code] = item.value;
            }
            this.initCurrentItem();
        }, err => {
            this.informationDialogService.showNetWorkError();
        })
    }

    getEmoloyeeList() {
        this.editGuestListService.getEmployee().subscribe(res => {
            if(res.status == "SUCCESS"){
                this.emoloyeeList = res.data;
            } else {
                this.informationDialogService.alert({
                    header: "Error",
                    message: res.message
                });
            }
        }, err => {
            this.informationDialogService.showNetWorkError();
        })
    }

    getGovernmentCompanyList() {
        this.governmentCompanyList = ["DICJ", "AMCM", "Other"];
    }

    selectCompany(flag, event, company: string = "") {
        if(this.currentItem.guestType == "EGTG"){
            this.governmentCompany.isShow = flag;
            if(flag) {
                event.stopPropagation();
            }
            if(company) {
                this.currentItem.guestCompany = company;
                this.governmentCompany.isOnlyRead = true;
            }
        }
    }

    initCurrentItem() {
        this.currentItem.guestType = this.currentItem.guestType ? this.currentItem.guestType : this.guestTypeList[0].code;
        this.currentItem.guestName = "";
        this.currentItem.guestCompany = "";
        this.governmentCompany.isOnlyRead = false;
        this.nameError = "";
        this.companyError = "";
    }

    checkEmployee(id) {
        for(let item of this.emoloyeeList){
            if(item.Id == id) {
                this.addGuest(<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>{
                    guestName: `${item.UserName} #${item.Department} #${item.Id}`,
                    guestType: this.currentItem.guestType,
                    guestCompany: this.currentItem.guestCompany
                });
                return;
            }
        }
        this.nameError = "Employee Not Found";
    }

    judgeIsEmpty(str: string) {
        return str ? str : "";
    }

    checkPatron(id) {
        this.editGuestListService.getPatronAndCheck(id).subscribe(res => {
            var name = res.patronName.filter((n)=> {return n.nameType=="Primary"})[0];
            this.addGuest(<PatronComp.Loyaltymgmtv1compissurancepatronCompPatronCompGuests>{
                guestName: `${this.judgeIsEmpty(name.prefix)} ${this.judgeIsEmpty(name.lastName)} ${this.judgeIsEmpty(name.middleName)} ${this.judgeIsEmpty(name.firstName)} #${res.id}`,
                guestType: this.currentItem.guestType,
                guestCompany: this.currentItem.guestCompany
            });
        }, err => {
            if(err.status == 400){
                this.nameError = "Patron Not Found";
            }else{
                this.informationDialogService.showNetWorkError();
            }
        })
    }

    checkBusinessOrGovernment(company) {
        if(!company) {
            this.nameError = "";
            this.companyError = "Require";
        }else{
            this.addGuest(this.currentItem);
        }
    }

    checkGuestInformation() {
        let name = this.currentItem.guestName;
        if(!name){
            this.nameError = "Require";
            return;
        }
        switch(this.currentItem.guestType){
            case "EGTE": this.checkEmployee(name);
                break;
            case "EGTP": this.checkPatron(name);
                break;
            case "EGTB": this.checkBusinessOrGovernment(this.currentItem.guestCompany);
                break;
            case "EGTG": this.checkBusinessOrGovernment(this.currentItem.guestCompany);
                break;
            default: this.addGuest(this.currentItem);
                break;  
        }
    }

    addGuest(item) {
        item = JSON.parse(JSON.stringify(item));
        this.guestList.push(item);
        this.initCurrentItem();
        this.nameError = "";
        this.companyError = "";
    }

    removeGuestList(guest) {
        let index = this.guestList.indexOf(guest);
        this.guestList.splice(index, 1);
    }

    closeDialog() {
        this.isShow = false;
        this.isShowChange.emit(false);
        this.finishEdit.emit(this.guestList);
    }
}
