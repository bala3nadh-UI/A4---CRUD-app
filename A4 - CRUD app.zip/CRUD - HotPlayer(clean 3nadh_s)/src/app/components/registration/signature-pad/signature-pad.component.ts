import { DOCUMENT } from '@angular/platform-browser';
import { Component, OnInit, ViewChild, Input, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShareDataService } from '../../../services/share-data.service';
const SignaturePad = require('signature_pad');
import { RegistrationService } from '../../../services/registration.service';
import { InfoType, DialogType } from '../enums';
import { RegisterErrorhandlerComponent } from '../register-errorhandler/register-errorhandler.component';


@Component({
  selector: 'app-signature-pad',
  templateUrl: './signature-pad.component.html',
  styleUrls: ['./signature-pad.component.css'],
  changeDetection : ChangeDetectionStrategy.OnPush
})
export class SignaturePadComponent extends RegisterErrorhandlerComponent implements OnInit {

  @ViewChild('signatureCanvas') signatureCanvas;
  patronId = null;
  signaturePad = null;
  sinatureBlob = null;
  loading = false;
  hasSaveClicked: Boolean = false;
  sigImg: any;
  patronNo:any;
  uploadResult:boolean = false;
  blobSignatureObj:any;
  property: string = " ";
  deviceInfo: any;
  htmlString = "";

  print: boolean = true;
  showIt: Boolean = true;
  device:any;
  clubs={};

 constructor(
    private router: Router,
    private shareDataService: ShareDataService,
    private activatedRoute: ActivatedRoute,
    private registerService:RegistrationService,
    private ref : ChangeDetectorRef
  ) {super();

  }

  ngOnInit() {
    window.MyFrameworkCall = window.MyFrameworkCall || {};
    this.activatedRoute.queryParams.subscribe(params => {
        this.patronNo = params["patronNo"];
        this.ref.markForCheck();
    });
    this.print = this.shareDataService.print;

    this.signatureCanvas = this.signatureCanvas.nativeElement;
    this.signaturePad = new SignaturePad.default(this.signatureCanvas);
    const calcCanvas = () => {
      const wid = window.innerWidth - (window.innerWidth * 0.1) - 2;
      this.signatureCanvas.width = wid > 595 ? 595 : wid;
      this.signatureCanvas.height = this.signatureCanvas.width / 2;
    };
    window.onresize = calcCanvas;
    calcCanvas();
    this.registerService.getDeviceInfo().then(res => {
      this.device = res;
    });     

  }

  clear() {
    this.signaturePad.clear();
  }

  back() {
    history.back();
  }

  save() {
    this.hasSaveClicked = true;
  }

  signAgain() {
    this.signaturePad.clear();
  }

  confirmRegister() {

    let step3DataObj = this.shareDataService.getStep3DataObj();
    let patronIDPhotoAsBlob = this.shareDataService.getPatronIDPhotoAsBlobImage();
    let patronPhotoAsBlob = this.shareDataService.getPatronPhotoAsBlobImage();
    let step4DataObj = this.shareDataService.getStep4DataObj();
    if(step4DataObj) {
      if(step4DataObj.title === "Miss") {
        step3DataObj.patronName[0].prefix = "PXMS"
      }
    }
    this.sigImg = this.signaturePad.toDataURL('image/png');
    this.shareDataService.insertSignImg(this.sigImg);
    // signature upload DOCUMENT
    this.signatureCanvas.toBlob(data=> {
         this.blobSignatureObj = data;
     });
     // let clubData = this.getClubData();
     //this.printPdf();
     this.deviceInfo = this.shareDataService.getDeviceInfo();
     let signupLocation = this.deviceInfo.locationName ? this.deviceInfo.locationName : "";
     let deviceID = this.deviceInfo.id ? this.deviceInfo.id : "";
     let allStepsData =  Object.assign({}, step3DataObj, step4DataObj, {signupLocation: signupLocation, signupDate : new Date(), signupDeviceId:deviceID}); 
     this.registerService.checkPatronIdentification(this.patronNo, allStepsData).subscribe(result => { 
          this.uploadIdScanned(this.patronNo, step3DataObj, patronIDPhotoAsBlob, patronPhotoAsBlob);
     }, err => {
          this.dialogMess(`Error in Patron Registration`, InfoType.ERROR, DialogType.ERROR, this.router);
          this.ref.markForCheck();
     });    
  }


  uploadIdScanned(patronId,formObj, patronIDPhotoAsBlob, patronPhotoAsBlob) {
    var result = false;
    
  if(patronIDPhotoAsBlob !=null && patronIDPhotoAsBlob.size > 0) {

    this.registerService.uploadDocument(patronId, patronIDPhotoAsBlob,"Patron Identification","PhotoIndentification.jpg").subscribe((data)=> {

      if(data) {
         let identityObj = formObj;
          identityObj.identification[0].createdDate = new Date();
          identityObj.identification[0].createdBy = localStorage.getItem('userID');
          identityObj.identification[0].lastModifiedDate = new Date();
          identityObj.identification[0].lastModifiedBy = localStorage.getItem('userID');
          identityObj.identification[0].country = formObj.country;
          identityObj.identification[0].stateProvince = formObj.stateProvince;
          identityObj.identification[0].status = "active";
          identityObj.id= this.registerService.getTempPatronNumber();
          identityObj.identification[0].expiryDate = formObj.purgeDate;
          identityObj.identification[0].documentName = data["documentName"] ? data["documentName"] : "";
          //this.deviceInfo = this.shareDataService.getDeviceInfo();
          //identityObj.signupLocation = this.deviceInfo.locationName ? this.deviceInfo.locationName : " ";
          //identityObj.signupHost = localStorage.getItem('userID') ? localStorage.getItem('userID') : " ";

          this.registerService.updateBasicInformationModifyIdentification(identityObj).subscribe((result)=> {
          },err => {
            this.dialogMess(`Network Error.`, InfoType.NONE, DialogType.INFO, this.router);
            this.ref.markForCheck();
          });

        this.registerService.uploadDocument(patronId, patronPhotoAsBlob,"Patron Photo","PatronPhoto.jpg").subscribe((data)=> {
            if(data) {
              this.uploadSignature(this.blobSignatureObj);
            } else {
              this.dialogMess(`Patron is updated with error in uploading the Patron Photo, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
              this.ref.markForCheck();
            }
        }, err=> {
          this.dialogMess(`Patron is updated with error in uploading the Patron Photo, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
          this.ref.markForCheck();
        });
      } else {
          this.dialogMess(`Patron is updated with error in uploading the Patron ID documents, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
          this.ref.markForCheck();
      }
    
    });

  } else {
      this.dialogMess(`Patron is updated with error in uploading the ID documents, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
      this.ref.markForCheck();
  }
 
}

  uploadSignature(blobSignatureObj) {

    this.registerService.uploadDocument(this.patronNo,blobSignatureObj,'Signature','eSignature.jpg').subscribe(result=> {
            if(result) {
              this.dialogMess(`Patron # ${this.patronNo} is updated successfully`, InfoType.REGISTER, DialogType.INFO, this.router);
              this.ref.markForCheck();
              window.MyFrameworkCall.setFullScreenMode();
            } else {
                this.dialogMess(`Patron is updated with error in uploading signature`, InfoType.REGISTER, DialogType.ERROR, this.router);
                this.ref.markForCheck();
            }
            },(err)=> {
                this.dialogMess(`Patron is updated with error in uploading signature`, InfoType.ERROR, DialogType.ERROR, this.router);
                this.ref.markForCheck();
      });

  }

  getClubData() {

    const validityDays = 90;
    const today = new Date();

    let clubData =  [{
      clubCode: "Mass Market",
      clubName : "Mass Market",
      location : this.device ? this.device.propertyName : null,
      tier : {
        tierCode : "CCB4",
        expiryDate : new Date(today.getFullYear(), today.getMonth(), today.getDate() + validityDays),
        minUpgradePoints : null,
        validDays: validityDays
      },
      isActive : true,
      autoDowngradeOrUpgrade : true,
      createdDate : new Date(),
      createdBy : localStorage.getItem("userID"),
      expriyDate : new Date(today.getFullYear(), today.getMonth(), today.getDate() + validityDays)
    }];
    return this.clubs = {
      clubs : clubData
    }

  }

  printPdf() {
    this.createHtmlStr();
  }

  createHtmlStr() {
    this.createPrintableArea();
    this.uploadHtml(this.htmlString);
  }

  createPrintableArea() {
    this.htmlString = this.shareDataService.completeHtml;

    //Title
    if (this.shareDataService.step5Title != undefined && this.shareDataService.step5Title != null) {
      let patronTitle = this.shareDataService.step5Title.toLowerCase();
      if (patronTitle != undefined && patronTitle != null) {
        this.htmlString = this.htmlString.replace('<input id="' + patronTitle + '" type="checkbox">', '<input id="' + patronTitle + '" type="checkbox" checked>');
      } 
    } 
    //Preffered Lang
    if (this.shareDataService.step5PrefLang != undefined && this.shareDataService.step5PrefLang != null) {
      let prefLang = this.shareDataService.step5PrefLang.toLowerCase();
      if (prefLang == "chinese") {
        this.htmlString = this.htmlString.replace('<input id="mandarin" type="checkbox">', '<input id="mandarin" type="checkbox" checked>');
      } else if (prefLang == "chinese (traditional hongkong)") {
        this.htmlString = this.htmlString.replace('<input id="cantonese" type="checkbox">', '<input id="cantonese" type="checkbox" checked>');
      } else if (prefLang == "english") {
        this.htmlString = this.htmlString.replace('<input id="eng" type="checkbox">', '<input id="english" type="checkbox" checked>');
      } else {
        this.htmlString = this.htmlString.replace('<input id="otherLang" type="checkbox">', '<input id="otherLang" type="checkbox" checked>');
      }
    }
    //ID Type
    if (this.shareDataService.step5IdType != undefined && this.shareDataService.step5IdType != null) {
      let idType = this.shareDataService.step5IdType.toLowerCase();
      if(idType.indexOf("passport") == -1){
        this.htmlString = this.htmlString.replace('<input id="idType" type="checkbox">', '<input id="idType" type="checkbox" checked>');
      } else {
        this.htmlString = this.htmlString.replace('<input id="passportType" type="checkbox">', '<input id="passportType" type="checkbox" checked>');
      };
    }
    //Mail
    let mailSms = this.shareDataService.step5SendSms;
    let mailDirect = this.shareDataService.step5DirectEmail;
    let mailEmail = this.shareDataService.step5SendEmail;
    if (mailSms == true && mailDirect != undefined && mailDirect != null && mailDirect != " " && mailEmail == true) {
      this.htmlString = this.htmlString.replace('<input id="all" type="checkbox">', '<input id="all" type="checkbox" checked>');
    } else {
      if (mailSms == true) {
        this.htmlString = this.htmlString.replace('<input id="sms" type="checkbox">', '<input id="sms" type="checkbox" checked>');
      } 
      if (mailDirect != undefined && mailDirect != null && mailDirect != "" && mailDirect != " ") {
        this.htmlString = this.htmlString.replace('<input id="mail" type="checkbox">', '<input id="mail" type="checkbox" checked>');
      } 
      if (mailEmail == true) {
        this.htmlString = this.htmlString.replace('<input id="email" type="checkbox">', '<input id="email" type="checkbox" checked>');
      }
    }
    //Property
    this.deviceInfo = this.shareDataService.getDeviceInfo();
    if (this.deviceInfo != undefined) {
      this.property = this.deviceInfo.propertyId;
    } else {
      this.property = "altira";      
    }    
    if (this.property != undefined && this.property != null) {
      let propElem = this.property.toLowerCase();
      if (propElem != undefined && propElem != null) {
        this.htmlString = this.htmlString.replace('<input id="' + propElem + '" type="checkbox">', '<input id="' + propElem + '" type="checkbox" checked>');
      }
    }
    
    this.htmlString = this.htmlString.replace('id="hostName"></b></div>', 'id="hostName"></b>' + localStorage.getItem('userID') + '</div>');
    this.htmlString = this.htmlString.replace('<img id="footerSign" width="350px" src="" />', '<img id="footerSign" width="350px" src="' + this.shareDataService.signImg + '" />');

    this.htmlString = this.htmlString.replace('id="footerAppDate"></div>', 'id="footerAppDate">' + this.shareDataService.appDate + '</div>');
  }
  
  uploadHtml(file: string) {
    this.registerService.uploadHtml(file, this.patronNo, this.property.toLowerCase()).subscribe(result => {
        //this.dialogMess(`PDF id uploaded successfully for the Patron # ${this.patronNo}`, InfoType.REGISTER, DialogType.INFO, this.router);
        //this.ref.markForCheck();
        this.routeBack();        
    },
    err => {
        let isPdfErr: boolean = true;
        this.shareDataService.insertPdfErr(isPdfErr);
        //this.dialogMess(`Error in Uploading PDF`, InfoType.ERROR, DialogType.ERROR, this.router);
        //this.ref.markForCheck();
        this.routeBack();
    });
  }

  routeBack() {
    this.shareDataService.insertPrint(true);
    this.shareDataService.insertSuccess("Registration Successful");
    this.router.navigate(['Registration']);
  } 

  okDialogClick(event) {
      switch(this.infoType) {
          case InfoType.REGISTER:
              //  this.baseRouter.navigate(['/PatronManagement/EditPatron/ModifyPatron', this.resp['desc']]);
              this.printPdf();
          break;
          default:
              this.closeDialog();
          break;
      }
  }
}
