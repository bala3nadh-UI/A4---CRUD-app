import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ShareDataService } from '../../../services/share-data.service';
import { RegistrationService } from '../../../services/registration.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { RegisterErrorhandlerComponent } from '../register-errorhandler/register-errorhandler.component';
import { InfoType, DialogType } from '../enums';

@Component({
  selector: 'app-register-step1',
  templateUrl: './register-step1.component.html',
  styleUrls: ['./register-step1.component.css']
})
export class RegisterStep1Component extends RegisterErrorhandlerComponent implements OnInit {

  isSuccess: boolean = false;
  successMsg: string = "Bala";
  step1UserRegFormGrp : FormGroup;
  
  constructor(private router: Router, private shareDataService: ShareDataService,
    private registrationService: RegistrationService, private fb: FormBuilder) {
      super(); 
                
              }

  ngOnInit() {
     this.step1UserRegFormGrp = this.fb.group({
      
        patronNumber : ['',[Validators.required]],
    
    });
    this.showSuccessMsg();
    setTimeout(() => {
        this.showPdfErr();
    },1000);    
  }

  step2GoAction({ value, valid }) {
      //this.router.navigate(['/Registration/Terms']);
      this.registrationService.setTempPatronNumber(value.patronNumber);
      this.registrationService.getPatronByPatronNumber(value.patronNumber).subscribe((res)=> {
        console.log(res);
        if(res!=null && res.patronType==="Temporary") {
            this.shareDataService.setStep1DataObj(res);
            this.router.navigate(['/Registration/Step2']);
        } else {
           this.dialogMess(`This Patron is Full Class already`, InfoType.REGISTER, DialogType.INFO, this.router);
        }
      },(err) => {
           this.dialogMess(`Cannot find the Patron!`, InfoType.REGISTER, DialogType.INFO, this.router);
      });
     
  }

  showSuccessMsg() {
      this.successMsg = this.shareDataService.successMsg;
      if (typeof this.successMsg != undefined && this.successMsg) {
          this.isSuccess = true;
          this.shareDataService.insertSuccess(null);
      }
  }

  showPdfErr() {
      let isPdfErr = this.shareDataService.isPdfErr;
      if(isPdfErr) {
        this.dialogMess(`PDF not generated!`, InfoType.REGISTER, DialogType.INFO, this.router);
      }
  }

    okDialogClick(event) {
         this.closeDialog();
    }

}
