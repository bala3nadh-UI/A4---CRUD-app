import { Component, OnInit, Input, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-photo-preview',
  templateUrl: './photo-preview.component.html',
  styleUrls: ['./photo-preview.component.css']
})
export class PhotoPreviewComponent implements OnInit {

  @Input() isDesktopDebugMode: boolean;
  @ViewChild('canvasElement') canvasNode;
  @ViewChild('canvasHiddenElement') canvasHiddenElement;
  @Input() patronIDPhoto:any;
  @Output() photoIDAsBlob = new EventEmitter<Object>(); 
  @Output() photoAsBlob = new EventEmitter<Object>(); 

  @Input() patronPhoto:any;

  canvas: HTMLCanvasElement = null;
  image : any = null;
  
  canvasHidden: HTMLCanvasElement = null;
  imageHidden : any = null;
  
  constructor() { 
      
  }

  ngOnInit() {

  }

  ngOnChanges() {
       if(this.patronIDPhoto != undefined && this.patronPhoto != undefined) {
          this.image = new Image();
          this.image.src = this.patronIDPhoto;
          this.canvas = this.canvasNode.nativeElement;
          let content = this.canvas.getContext('2d');

          this.imageHidden = new Image();
          this.imageHidden.src = this.patronPhoto;
          this.canvasHidden = this.canvasHiddenElement.nativeElement;
          let contentHidden = this.canvasHidden.getContext('2d');

          setTimeout(()=> {

                $('.step3-photo-preview').append("<img id='hiddenImageID' src='"+this.patronIDPhoto+"' style='display:none'/>");
                var l_widthx = $('#hiddenImageID').width();
                var l_heighty = $('#hiddenImageID').height();
                this.canvas.width = l_widthx;
                this.canvas.height = l_heighty;

                content.drawImage(this.image,0,0,this.canvas.width,this.canvas.height); 
                this.canvas.toBlob(data => {
                  this.photoIDAsBlob.emit(data);
                });

                $('.step3-photo-preview').append("<img id='hiddenImage' src='"+this.patronPhoto+"' style='display:none'/>");
                var l_width = $('#hiddenImage').width();
                var l_height = $('#hiddenImage').height();
                this.canvasHidden.width = l_width;
                this.canvasHidden.height = l_height;
                
                contentHidden.drawImage(this.imageHidden,0,0,this.canvasHidden.width,this.canvasHidden.height); 
                this.canvasHidden.toBlob(data => {
                  this.photoAsBlob.emit(data);
                });

          },200);

      }
  }

  ngOnDestroy() {
    console.log("photo preview ngOnDestroy");
  }

}
