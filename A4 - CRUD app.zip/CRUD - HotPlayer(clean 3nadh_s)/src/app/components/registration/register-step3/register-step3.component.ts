import { Patron } from './../../../dataModels/Patron';
import { SelectItem } from './../../../dataModels/SelectItem';
import { RegistrationService } from './../../../services/registration.service';
import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef, ChangeDetectionStrategy} from '@angular/core';
import { RegistrationStep3Model}  from  "../../../dataModels/models";
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { DialogType, InfoType } from './../enums';
import {RegisterErrorhandlerComponent} from './../register-errorhandler/register-errorhandler.component'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { ShareDataService } from '../../../services/share-data.service';

@Component({
  selector: 'app-register-step3',
  templateUrl: './register-step3.component.html',
  styleUrls: ['./register-step3.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterStep3Component extends RegisterErrorhandlerComponent implements OnInit {
  
  step3UserRegFormGrp : FormGroup;
  isDesktopDebugMode:boolean = true;
  idType : SelectItem[];
  
  countryArrs: any = [];
  patronIDPhoto:any;
  patronIDPhotoAsBlob : Blob;
  patronPhoto:any;
  patronPhotoAsBlob : Blob;
  changeStep3DatafromAndriodEmittedSubscription:any;
  emitPatronIDPhotofromAndriodSubscription:any;
  maxDateOfBirth: Date;
  minDateOfBirth: Date;
  minDateOfExpiry: Date;
  selectedDateOfBirth:Date;
  provinceOption:any = [];
  defaultIDType:string = '';
  isPurgeDateDisabled:boolean = false;
  
  constructor(private fb: FormBuilder, private router: Router, private registrationService: RegistrationService, 
              private ref: ChangeDetectorRef, private shareDataService: ShareDataService) {
     super();
    this.idType = [];
     this.idType.push({label:'-- ID Type --', value:null});
     this.idType.push({label:'CHNMVISA – 中文', value:'IDCV'});
     this.idType.push({label:'HK_ID', value:'IDHK'});
     this.idType.push({label:'MACAU_ID', value:'IDMO'});
     this.idType.push({label:'PASSPORT', value:'IDPS'});
     this.idType.push({label:'CHINA EEP CARD', value:'IDEEP'});
     // this.idType.push({label:'Taiwan CP', value:'TCP'});
     this.registrationService.getCountryCodesDropdownList(this.countryArrs);
     this.retrieveStep3DataFromAndriod();
      this.setBirthdayMaxMin();
      this.setExpiryDateMin();
   }

  ngOnInit() {
    this.defaultIDType = this.registrationService.getIDType();
    if(this.defaultIDType) {
        if("IDHK" === this.defaultIDType) {
            this.isPurgeDateDisabled = true;
        }
    }
    let step3DataObj = this.shareDataService.getStep3DataObj();
    if(!step3DataObj) {
        this.step3UserRegFormGrp = this.fb.group({
          patronName : this.fb.array([this.createPatronName(), this.createPatronChineseName()]),
          dateOfBirth : ['',[Validators.required]],
          identification : this.fb.array([this.fb.group({
            idType:['',[Validators.required]],
            idNumber:['',[Validators.required]],
          })]),
          country : ['',[Validators.required]],
          stateProvince : [],
          gender : ['',[Validators.required]],
          status : ['Active'],
          purgeDate : {value:'',disabled:this.isPurgeDateDisabled},
          playerType : ['Player']
      });
    } else {
      this.step3UserRegFormGrp = this.fb.group({
          patronName : this.fb.array([
            this.fb.group({
              firstName : [step3DataObj.patronName[0].firstName,[Validators.required]],
              lastName : [step3DataObj.patronName[0].lastName,[Validators.required]],
              nameType : ['Primary'],
              prefix : ['PXMR'],
              middleName : ['']

          }), this.fb.group({
          firstName : [step3DataObj.patronName[1].firstName]
          })]),
        dateOfBirth : [step3DataObj.dateOfBirth,[Validators.required]],
        identification : this.fb.array([this.fb.group({
          idType:[step3DataObj.identification[0].idType,[Validators.required]],
          idNumber:[step3DataObj.identification[0].idNumber,[Validators.required]],
        })]),
        country : [step3DataObj.country,[Validators.required]],
        stateProvince : [],
        gender : [step3DataObj.gender,[Validators.required]],
        status : ['Active'],
        purgeDate : [step3DataObj.purgeDate],
        playerType : ['Player']
      });
      this.onAddressCountryChanges({value:step3DataObj.country});
      setTimeout(() => {
        this.step3UserRegFormGrp.patchValue({gender:step3DataObj.gender,stateProvince:step3DataObj.stateProvince});
      },10);
  
      
    }
   
    this.ref.markForCheck();

  }

  ngAfterViewInit() {
    let patronIDPhotoAsBlob = this.shareDataService.getPatronIDPhotoAsBlob();
    if(patronIDPhotoAsBlob) {
      this.patronIDPhoto = this.shareDataService.getPatronIDPhotoAsBlob();
      this.patronPhoto = this.shareDataService.getPatronPhotoAsBlob();
      this.ref.markForCheck();
    }
  }

   createPatronName() : FormGroup {
      return this.fb.group({
            firstName : ['',[Validators.required]],
            lastName : ['',[Validators.required]],
            nameType : ['Primary'],
            prefix : ['PXMR'],
            middleName : ['']

      });
    }

  createPatronChineseName(): FormGroup {

    return this.fb.group({
         firstName : ['']
    });


  }
  reset() {
     this.step3UserRegFormGrp.reset({});
     this.ref.markForCheck();

  }

  onSubmit({ value, valid }: { value: Patron, valid: boolean }) {
      value.dateOfBirth = new Date(value.dateOfBirth);
      value.purgeDate = new Date(value.purgeDate);
      value.patronType = "Mass";

       if(this.validateMandatoryFields(value))
       {
         return;
       }

       
      if(this.validateExpiryDate(value.purgeDate)) {
        return;
      }

     
      let step1And3ExtnObj = $.extend(true, this.shareDataService.getStep1DataObj(), value);

      Observable.forkJoin([this.registrationService.checkPatronDuplicateByName(value),
                            this.registrationService.checkPatronDuplicateById(value)]).subscribe(results=> {
              if(results[0].length>0 || results[1].length>0) {

                this.dialogMess(`Duplicate Patron.`, InfoType.NONE, DialogType.INFO, this.router);
                this.ref.markForCheck();
              } else {
              // UNCOMMENT BELOW CODE
              this.patronNo =this.registrationService.getTempPatronNumber();
              this.registrationService.emitChange(value);
              this.shareDataService.setStep3DataObj(step1And3ExtnObj);
              this.shareDataService.setPatronIDPhotoAsBlobImage(this.patronIDPhotoAsBlob);
              this.shareDataService.setPatronPhotoAsBlobImage(this.patronPhotoAsBlob);
              this.router.navigate(['/Registration/Step4'],{queryParams:{patronNo:this.patronNo}}); 
              }

      }, err => {
        this.dialogMess(`Network Error.`, InfoType.NONE, DialogType.INFO, this.router);
        this.ref.markForCheck();
      }); 

  }
  goBack() {
    this.router.navigate(['/Registration/Step2']);
  }
   async retrieveStep3DataFromAndriod() {

    this.changeStep3DatafromAndriodEmittedSubscription = await this.registrationService.changeStep3DatafromAndriodEmitted$.take(1).subscribe((resultMap)=> {
        resultMap.dateOfBirth =moment(resultMap.dateOfBirth,'DD/MM/YYYY').toDate();
        resultMap.purgeDate = (resultMap.purgeDate)? moment(resultMap.purgeDate,'DD/MM/YYYY').toDate():'';
        this.registrationService.getCountryCodes().then(res => {
          let cCode = resultMap.country;
          resultMap.country = res.get(cCode);
          let selectedIDType = this.registrationService.getIDType();
          resultMap.identification[0].idType = selectedIDType; 
           if(resultMap.gender === "F") {
            resultMap.gender = "Female";
          } else if(resultMap.gender === "M") {
            resultMap.gender = "Male";
          }
          if(this.defaultIDType) {
            if("IDHK" === this.defaultIDType) {
                resultMap.country = "Hong Kong";
            } else if("IDMO" === this.defaultIDType) {
              resultMap.country = "Macao";
            } else if("IDEEP" === this.defaultIDType || "IDCV" === this.defaultIDType) {
              resultMap.country = "CHINA";
            }
          }
          this.onAddressCountryChanges({value:resultMap.country});
          this.step3UserRegFormGrp.patchValue(resultMap);
           setTimeout(() => {
            this.ref.markForCheck();
          },10);
        });
       
    });

    this.emitPatronIDPhotofromAndriodSubscription =  await this.registrationService.emitPatronIDPhotofromAndriod$.take(1).subscribe(data => {
        this.patronIDPhoto = data.dataPatronIDPhoto;
        this.patronPhoto = data.dataPatronPhoto;
        this.shareDataService.setPatronIDPhotoAsBlob(data.dataPatronIDPhoto);
        this.shareDataService.setPatronPhotoAsBlob(data.dataPatronPhoto);
        setTimeout(() => {
          this.ref.markForCheck();
        },10);
    });

    
  }

  onAddressCountryChanges(type) {
      let stateCtrl = this.step3UserRegFormGrp.get('stateProvince');
      stateCtrl.enable({ onlySelf: true});
      this["provinceOption"] = [{ label: "-- Select State or Province --", value: null }];
      if(!type || type.value == "Hong Kong" || type.value == "Macao") {
        this["provinceOption"] = [];
        this["provinceOption"] = [{ label: "-- Select State or Province --", value: null }];
        stateCtrl.disable({ onlySelf: true});
      } else {
          this.registrationService.getStatesByCountryName(type.value).then((data) => {
            if(!data.length) {
              this["provinceOption"] = [];
              this["provinceOption"] = [{ label: "-- Select State or Province --", value: null }];
              stateCtrl.disable({ onlySelf: true, emitEvent: true });
            } else {
              this["provinceOption"] = [{ label: "-- Select State or Province --", value: null }];
              this['provinceOption'] = this['provinceOption'].concat(data);
              stateCtrl.enable({ onlySelf: true});
            }
        });
      }

  }

  getScannedPhotoAsBlob(evnt) {
    this.patronIDPhotoAsBlob = evnt;
  }

  getPhotoAsBlob(evnt) {
    this.patronPhotoAsBlob = evnt;
  }

  uploadIdScanned(patronId,formObj) {
      var result = false;
      
    if(this.patronIDPhotoAsBlob !=null && this.patronIDPhotoAsBlob.size > 0) {

      this.registrationService.uploadDocument(patronId, this.patronIDPhotoAsBlob,"Patron Identification","PhotoIndentification.jpg").subscribe((data)=> {

        if(data) {
           let identityObj = formObj;
            identityObj.identification[0].createdDate = new Date();
            identityObj.identification[0].createdBy = localStorage.getItem('userID');
            identityObj.identification[0].lastModifiedDate = new Date();
            identityObj.identification[0].lastModifiedBy = localStorage.getItem('userID');
             identityObj.identification[0].country = formObj.country;
             identityObj.identification[0].stateProvince = formObj.stateProvince;
            identityObj.identification[0].status = "active";
            identityObj.id= this.registrationService.getTempPatronNumber();
            identityObj.identification[0].expiryDate = formObj.purgeDate;
            identityObj.identification[0].documentName = data["documentName"] ? data["documentName"] : "";

            this.registrationService.updateBasicInformationModifyIdentification(identityObj).subscribe((result)=> {
            },err => {
              this.dialogMess(`Network Error.`, InfoType.NONE, DialogType.INFO, this.router);
              this.ref.markForCheck();
            });

          this.registrationService.uploadDocument(patronId, this.patronPhotoAsBlob,"Patron Photo","PatronPhoto.jpg").subscribe((data)=> {
              if(data) {
                this.router.navigate(['/Registration/Step4'],{queryParams:{patronNo:this.patronNo}});
              } else {
                this.dialogMess(`Patron is registered with error in uploading the ID documents, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
                this.ref.markForCheck();
              }
          });
        } else {
            this.dialogMess(`Patron is registered with error in uploading the ID documents, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
            this.ref.markForCheck();
        }
      
      });

    } else {
        this.dialogMess(`Patron is registered with error in uploading the ID documents, The Patron # is ${patronId}`, InfoType.REGISTER, DialogType.INFO, this.router);
        this.ref.markForCheck();
    }
   
  }

     okDialogClick(event) {
        switch(this.infoType) {
            case InfoType.REGISTER:
               //  this.baseRouter.navigate(['/PatronManagement/EditPatron/ModifyPatron', this.resp['desc']]);
              this.router.navigate(['/Registration/Step4'],{queryParams:{patronNo:this.patronNo}});
            break;
            default:
                this.closeDialog();
            break;
        }
    }

    ngOnDestroy() {
      this.changeStep3DatafromAndriodEmittedSubscription.unsubscribe();
      this.emitPatronIDPhotofromAndriodSubscription.unsubscribe();
    }

    setBirthdayMaxMin() {
    var today = new Date();
    var maxYear = today.getFullYear() - 21;
    var todayMonth = today.getMonth();

    var maxDay = today.getDate();
    this.maxDateOfBirth = new Date(maxYear, todayMonth, maxDay);

    var minYear = today.getFullYear() - 120;
    this.minDateOfBirth = new Date(minYear, todayMonth, maxDay);
  }

  setExpiryDateMin() {
    //set expiryDate min date
    var date = new Date();

    date.setDate(date.getDate());
    this.minDateOfExpiry = date;
  }

   onBlurBirthday(event) {
    var checkStatus = true;
    this.selectedDateOfBirth = moment(event.currentTarget.value,'MM/DD/YYYY').toDate();
    if (this.selectedDateOfBirth) {
      var birthday = this.selectedDateOfBirth.getTime();
      var maxBirthday = this.maxDateOfBirth.getTime();
      var minBirthday = this.minDateOfBirth.getTime();

      if (birthday > maxBirthday || birthday < minBirthday) {
        this.dialogMess("The patron's age should be greater than 21.");

      }
    }
   }

    onBlurExpiryday(event) {
    let expiryDate = moment(event.currentTarget.value,'MM/DD/YYYY').toDate();
    this.validateExpiryDate(expiryDate);   
    }

  validateExpiryDate(expiryDate) {
    if (expiryDate && expiryDate.getTime() < this.minDateOfExpiry.getTime()) {
      this.dialogMess("The Expiry date for the ID should be later than today.");
         return true;
     
    } else {
      return false;
    }
  }

  validateMandatoryFields(value){
    if((value.identification[0].idType === undefined) || (value.identification[0].idType === null) || (value.identification[0].idType === "") ){
      this.dialogMess("ID Type is mandatory");
            return true;
    } else if((value.patronName[0].firstName === undefined)|| (value.patronName[0].firstName === null) || (value.patronName[0].firstName === "")){
      this.dialogMess("First Name is mandatory");
      return true;
    } 
    else if((value.patronName[0].lastName === undefined)|| (value.patronName[0].lastName === null) || (value.patronName[0].lastName === "")){
      this.dialogMess("Last Name is mandatory");
      return true;
    } 
    else if((value.identification[0].idNumber === undefined)|| (value.identification[0].idNumber === null) || (value.identification[0].idNumber === "")){
      this.dialogMess("Id Number is mandatory");
      return true;
    } 
    else if((value.country === undefined)|| (value.country === null) || (value.country === "")){
      this.dialogMess("Country is mandatory");
      return true;
    } else if(value.dateOfBirth){
       
        this.selectedDateOfBirth = moment(value.dateOfBirth,'MM/DD/YYYY').toDate();
       
          var birthday = this.selectedDateOfBirth.getTime();
          var maxBirthday = this.maxDateOfBirth.getTime();
          var minBirthday = this.minDateOfBirth.getTime();
    
          if (birthday > maxBirthday || birthday < minBirthday) {
            this.dialogMess("The patron's age should be greater than 21.");
             return true;
      }
    } 
     else {
      return false;
    }

  }

}
