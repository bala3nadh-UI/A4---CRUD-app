import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {InfoType, DialogType} from './../enums';

@Component({
  selector: 'app-register-errorhandler',
  templateUrl: './register-errorhandler.component.html',
  styleUrls: ['./register-errorhandler.component.css']
})
export class RegisterErrorhandlerComponent implements OnInit {

  private baseRouter: Router;

   infoType: InfoType = InfoType.NONE;
  dialogType: DialogType = DialogType.INFO;

  dialog: any = {
        dialogType: DialogType.INFO,
        content: '',
        header:''
    };
    dialogVisible: boolean = false;
    confirmDialogVisible: boolean = false;
    patronNo:string;

  constructor() { }

  ngOnInit() {
  }

  dialogMess(mess: any, infoType: InfoType = InfoType.NONE, dialogType: DialogType = DialogType.INFO, baseRouter: Router = null) {
       
        this.infoType = infoType;
        this.dialog.dialogType = dialogType;
        if (typeof mess === 'object') {
            if (typeof mess['json'] === 'function') {
                const jData = mess.json();
                this.dialog.content = jData['error_description'];
            } else {
                this.dialog.content = mess.toString();
            }
        } else {
            this.dialog.content = mess;
        }
        switch(this.dialog.dialogType) {
            case DialogType.INFO:
                this.dialog.header ="Information";
                this.dialogVisible = true;
            break;
            case DialogType.CONFIRM:
                this.dialog.header ="Confirmation";
                this.confirmDialogVisible = true;
            break;
            case DialogType.ERROR:
                this.dialog.header ="Error message";
                this.dialogVisible = true;
            break;
        }
    }

    closeDialog() {
        this.confirmDialogVisible = false;
        this.dialogVisible = false;
    }

}
