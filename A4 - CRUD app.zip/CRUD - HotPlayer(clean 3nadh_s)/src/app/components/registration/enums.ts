 export enum InfoType {
    SCAN = 1,
    CAPTURE = 2,
    REGISTER = 3,
    NONE = 0,
    ERROR = 4
  }

  export enum DialogType {
    INFO = 1,
    CONFIRM = 2,
    ERROR = 3
  }