import { RegistrationService } from './../../services/registration.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalLangConstVariable, GlobalLangVariable } from '../../globals';
import { LoginService } from '../../services/login.service';
import { InformationDialogService } from '../../services/information-dialog.service';
import { ShareDataService } from '../../services/share-data.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  userInformation: any;

  constructor(
    private loginService: LoginService,
    private router: Router,
    private informationDialogService: InformationDialogService,
    private registrationService : RegistrationService,
    private shareDataService: ShareDataService
  ) {
      this.regStepsData();

  }

  ngOnInit() {
     setTimeout((router: Router) => {
        this.router.navigate(['AppLogin']);
    }, 900000); //time out after 15 mins

     /*this.userInformation = this.loginService.getUserInformation();   //By-passing Authentication
        if(this.userInformation){

        }else{
            this.logOut();
        }*/
  }

  regStepsData() {
    this.registrationService.changeEmitted$.subscribe(dataObj => {
        this.shareDataService.insertData(dataObj);
    });
    this.shareDataService.insertPrint(true);
    this.registrationService.emitStep3PagefromAndriod$.subscribe(()=> {
              this.router.navigate(['/Registration/Step3']);   
    });
    
  }

  logOut() {
        this.loginService.clearUserInformation();
        localStorage.clear();
        this.router.navigate(["AppLogin"]);
    }

   onDeactivate() {
        document.body.scrollTop = 0;
   }

}

