import { Component, OnInit } from '@angular/core';
import { RegistrationStep4Model, SelectItem}  from  "../../../dataModels/models";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistrationService } from '../../../services/registration.service';
import { ShareDataService } from '../../../services/share-data.service';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import * as _ from "lodash";


@Component({
  selector: 'app-register-step5',
  templateUrl: './register-step5.component.html',
  styleUrls: ['./register-step5.component.css']
})
export class RegisterStep5Component implements OnInit {

  step5UserRegFormGrp : FormGroup;
  sources : SelectItem[];
  areaCodes : SelectItem[];

  data: any;
  print: boolean = true;
  dom2img: any;
  dom2imgBase64: any;
  encodedData: any;
  html4rPdf: any;
  dob2Html: any;
  dobDD2Html: any;
  dobMM2Html: any;
  dobYYYY2Html: any;

  patronNumber = "";
  title = "";
  familyName = "";
  givenName = "";
  chineseName = "";
  dob: Date;
  nationality = "";
  idType = "";
  idNumber:number;
  address = "";
  addressLine2 = "";
  city = "";
  country = "";
  province = "";
  postCode = "";
  mobile = "";
  home = "";
  eMail = "";
  prefLang:string;
  sendSms: boolean;
  directEmail = "";
  sendEmail: boolean;
  appDate:string="";
  preferredLanguageOptions : SelectItem[] = [
    {
        "label":"----Select----",
        "value":null
    }

];
   
 

  private identificationTypeData: any = {};

  constructor(
    private router: Router, 
    private registrationService : RegistrationService,
    private shareDataService: ShareDataService,
    private activatedRoute:ActivatedRoute) { 
        
    }

  ngOnInit() {
      //console.log(this.RegistrationStep4Model);
      this.activatedRoute.queryParams.subscribe(params=> {
        this.patronNumber = params["patronNo"];
        this.print = this.shareDataService.print;
        this._getIdentificationType().then((res)=> {
          this.getPatronDetailInfo(this.patronNumber);
        }, (err)=> {
          console.log("[_getIdentificationType->getActiveCategoryLookupCodes] Network Error Code: " + err.status);
        });
        
      });
        this.getPreferredLanguages();
  }

  getPatronDetailInfo(patronNumber) {

    let step3ObjData = this.shareDataService.getStep3DataObj();
    let step4ObjData = this.shareDataService.getStep4DataObj();
    let allStepsData =  Object.assign({}, step3ObjData, step4ObjData);
    this.patronNumber = patronNumber;
    this.title = allStepsData.title;
    this.familyName = allStepsData.patronName[0].lastName;
    this.givenName = allStepsData.patronName[0].firstName;
    this.chineseName = allStepsData.patronName[1].firstName;
    this.dob = allStepsData.dateOfBirth;
    this.nationality = allStepsData.address[0].country;
    this.idType =this.identificationTypeData[allStepsData.identification[0]["idType"]];
    this.idNumber = allStepsData.identification[0]["idNumber"];
    this.address = allStepsData.address[0].addressLine1;
    this.addressLine2 = allStepsData.address[0].addressLine2;
    this.city = allStepsData.address[0].city;
    this.country = allStepsData.country;
    this.province = allStepsData.stateProvince ? allStepsData.stateProvince : " ";
    this.postCode = allStepsData.address[0].postcode;
    this.mobile = allStepsData.phones[0].phoneNo;
    this.home = allStepsData.phones[1].phoneNo;
    this.eMail = allStepsData.email;
    let lang =  this.preferredLanguages(allStepsData.preferredLanguage);
    this.prefLang = lang;
    this.sendSms = allStepsData.sendSMS;
    this.directEmail = allStepsData.email;
    this.sendEmail = allStepsData.sendEmail;
    this.appDate = moment().format('DD/MM/YYYY');
  }

  save() {
    let node = document.getElementById('patron-info').innerHTML;
    //this.shareDataService.insertstep5Img(node);

    //Date format logic
    var dd = this.dob.getDate();
    var mm = this.dob.getMonth()+1; 
    var yyyy = this.dob.getFullYear();
    let day: string = dd.toString();
    let month: string = mm.toString();
    let year: string = yyyy.toString();
    if(dd<10) 
    {
        day='0'+dd;
        this.dobDD2Html = '0'+dd;
    } else {
        this.dobDD2Html = dd;
    }
    if(mm<10) 
    {
        month='0'+mm;
        this.dobMM2Html = '0'+mm;
    } else {
        this.dobMM2Html = mm;
    } 
    this.dobYYYY2Html = year;
    this.dob2Html = day+'/'+month+'/'+year;

    this.buildNewHtml();
    this.shareDataService.insertstep5Html(this.html4rPdf, this.title, this.prefLang, this.sendSms, this.directEmail, this.sendEmail, this.idType, this.appDate);
    this.router.navigate(['/Registration/Terms'],{queryParams:{patronNo:this.patronNumber}});
  }

  buildNewHtml() {

    this.html4rPdf = '<!DOCTYPE html> ';
    this.html4rPdf += '<html> ';
    this.html4rPdf += '<head> ';
    this.html4rPdf += '    <meta charset="utf-8"> ';
    this.html4rPdf += '    <style> ';
    this.html4rPdf += '        body { ';
    this.html4rPdf += '            width: 550px; ';
    this.html4rPdf += '            font-size: 12px; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        #header { ';
    this.html4rPdf += '            width: 100%; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        .section_header { ';
    this.html4rPdf += '            background-color: #000; ';
    this.html4rPdf += '            color: #fff; ';
    this.html4rPdf += '            padding-left: 10px; ';
    this.html4rPdf += '            font-size: 16px; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        .box { ';
    this.html4rPdf += '            border: 1px solid #000; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        .info-row { ';
    this.html4rPdf += '            display: flex; ';
    this.html4rPdf += '            display: -webkit-flex; ';
    this.html4rPdf += '            padding-top: 15px; ';
    this.html4rPdf += '            width: 100%; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        .underline { ';
    this.html4rPdf += '            border-bottom: 1px solid #000; ';
    this.html4rPdf += '        } ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        ol li { ';
    this.html4rPdf += '            margin: 10px 0px; ';
    this.html4rPdf += '            /*font-size:12px;*/ ';
    this.html4rPdf += '        } ';
    this.html4rPdf += '    </style> ';
    this.html4rPdf += '</head> ';
    this.html4rPdf += ' ';
    this.html4rPdf += '<!-- header table--> ';
    this.html4rPdf += ' ';
    this.html4rPdf += '<body> ';
    this.html4rPdf += '    <div style="display:none"></div> ';
    this.html4rPdf += '    <div style="width: 100%; display: -webkit-flex; display: flex"> ';
    this.html4rPdf += '        <div style="flex: 1;"> ';
    this.html4rPdf += '            <div id="form_title" style="margin-bottom: 30px; font-size: 20px; font-weight: bold"> ';
    this.html4rPdf += '                會員申請表格 ';
    this.html4rPdf += '        ';
    this.html4rPdf += '                <br /> ';
    this.html4rPdf += '                <span style="font-size: 14px">MEMBERSHIP APPLICATION FORM</span> ';
    this.html4rPdf += '            </div> ';
    this.html4rPdf += '            <div style="margin-bottom: 30px; font-size: 14px"> ';
    this.html4rPdf += '                會員號碼 ';
    this.html4rPdf += '        ';
    this.html4rPdf += '                <br /> ';
    this.html4rPdf += '                Membership No: ';
    this.html4rPdf += '      ';
    this.html4rPdf += '            </div> ';
    this.html4rPdf += '            <div class="underline">' + this.patronNumber + '</div> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div class="box" style="-webkit-flex: 1; flex: 1; margin-left: 5px">&nbsp;</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <!-- personal infomation --> ';
    this.html4rPdf += '    <div class="section_header" style="height: 25px; line-height: 25px;"> ';
    this.html4rPdf += '        個人資料 Personal Information ';
    this.html4rPdf += '  ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div> ';
    this.html4rPdf += '            先生 Mr <input id="mr" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="margin-left: 25px;"> ';
    this.html4rPdf += '            女士 Ms <input id="miss" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="margin-left: 25px;">太太 Mrs <input id="mrs" type="checkbox"></div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.20; flex: 0.20;">姓 Family Name:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.familyName + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;">名 Given Name:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.givenName + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.3; flex: 0.3;">中文姓名 Name in Chinese:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.7; flex: 0.7; margin-left: 10px;">' + this.chineseName + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.3; flex: 0.3;">出生日期 Date of Birth:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.1; flex: 0.1;">' + this.dobDD2Html + '</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.14; flex: 0.14; margin-left: 10px;">(日dd)</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.1; flex: 0.1; margin-left: 10px;">' + this.dobMM2Html + '</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.14; flex: 0.14; margin-left: 10px;">(月mm)</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.1; flex: 0.1; margin-left: 10px;">' + this.dobYYYY2Html + '</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.22; flex: 0.22; margin-left: 10px;">(年yy)</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;">國藉 Nationality:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.nationality + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.35; flex: 0.35;"> ';
    this.html4rPdf += '            旅遊護照 Passport <input id="passportType" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.25; flex: 0.25;"> ';
    this.html4rPdf += '            身份證 ID <input id="idType" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.1; flex: 0.1;">號碼 No:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.3; flex: 0.3;">' + this.idNumber + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;">聯絡地址 Address:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.address + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;"></div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.addressLine2 + '</div> ';
    this.html4rPdf += '    </div> ';    
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.1; flex: 0.1;">城市 City:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.4; flex: 0.4;">' + this.city + '</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.15; flex: 0.15; margin-left: 10px">省份 Province:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.35; flex: 0.35;"> ';
    this.html4rPdf += '            ' + this.province + ' ';
    this.html4rPdf += ' ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.15; flex: 0.15;">國家 Country:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.85; flex: 0.85; margin-left: 10px;"> ';
    this.html4rPdf += '            ' + this.country + ' ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;">郵政編號 Post Code:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.8; flex: 0.8; margin-left: 10px;">' + this.postCode + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.3; flex: 0.3;">聯絡電話 Contact No</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.7; flex: 0.7; margin-left: 10px;">&nbsp;</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.15; flex: 0.15;">手機 Mobile:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.35; flex: 0.35;">' + this.mobile + '</div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.13; flex: 0.13; margin-left: 10px;">家用 Home:</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.37; flex: 0.37; margin-left: 10px;">' + this.home + '</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 1; flex: 1;">慣用語言 （請選一項）Preferred Language(Please choose one)</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.2; flex: 0.2;"> ';
    this.html4rPdf += '            英文 English <input id="eng" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.25; flex: 0.25; margin-left: 5px"> ';
    this.html4rPdf += '            普通話 Mandarin <input id="mandarin" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.28; flex: 0.28; margin-left: 5px"> ';
    this.html4rPdf += '            廣東話 Cantonese <input id="cantonese" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.11; flex: 0.11; margin-left: 5px">其他 Other</div> ';
    this.html4rPdf += '        <div class="underline" style="-webkit-flex: 0.16; flex: 0.16; margin-left: 5px;"> ';
    this.html4rPdf += '            <input id="otherLang" type="checkbox"> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 1; flex: 1; font-size: 13px;">本人不希望收到以下宣傳物品 I DO NOT wish to receive the following promotional material(s):</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.5; flex: 0.5;"> ';
    this.html4rPdf += '            <input id="mail" type="checkbox"> 會員通訊 Direct Mail ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.5; flex: 0.5; margin-left: 10px;"> ';
    this.html4rPdf += '            <input id="sms" type="checkbox"> 電話通訊 SMS ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.5; flex: 0.5;"> ';
    this.html4rPdf += '            <input id="email" type="checkbox"> 電子郵件 Electronic Direct Mail ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.5; flex: 0.5; margin-left: 10px;"><input id="all" type="checkbox"> 以上任何宣傳物品 All of the Above</div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row" style="text-align: justify;"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 1; flex: 1;"> ';
    this.html4rPdf += '            <strong>會員條款及細則</strong> ';
    this.html4rPdf += '            <br /> ';
    this.html4rPdf += '            <ol> ';
    this.html4rPdf += '                <li>新濠會/皇璽會/摩卡會是新濠博亞(澳門)股份有限公司(以下稱為新濠博亞)獎賞會籍，只適用於新濠天地/新濠影滙/澳門新濠鋒/摩卡娛樂場。</li> ';
    this.html4rPdf += '                <li>此條款及細則是參與新濠會/皇璽會/摩卡會的基本規則，而新濠會/皇璽會/摩卡會將保留修改之權利。 </li> ';
    this.html4rPdf += '                <li>提交此申請表格給新濠博亞表示閣下要求申請成為新濠會/皇璽會/摩卡會會員。新濠博亞對會員申請有獨立裁決權。若新濠博亞接受此會員申請，申請人將獲發會員卡一張，並會被視為新濠會/皇璽會/摩卡會會員(以下稱為「會員」)。使用新濠會/皇璽會/摩卡會會員卡以及其他相關優惠，即表示會員接納新濠會/皇璽會/摩卡會的條款及細則。</li> ';
    this.html4rPdf += '                <li>每位會員只會獲發一個會籍。</li> ';
    this.html4rPdf += '                <li>新濠會/皇璽會/摩卡會不會開放予21歲以下的人士、法律上的個體或團體。申請人必須出示有效的身份證明文件，會籍部職員會為申請人作身份識別。新濠會/皇璽會/摩卡會將為會籍申請人拍攝個人面部照片，以便更準確地為每名會員進行身份確認，以及防止其會員卡被他人盜用。 </li> ';
    this.html4rPdf += '                <li>新濠會/皇璽會/摩卡會會籍費用全免。</li> ';
    this.html4rPdf += '                <li>會員將獲發新濠會/皇璽會/摩卡會會員卡一張，卡上清楚列明申請人的姓名及會員編號。</li> ';
    this.html4rPdf += '                <li>新濠會/皇璽會/摩卡會會員卡只供會員本人使用，不得轉讓。</li> ';
    this.html4rPdf += '                <li>所有獎賞及其他優惠必須由會員卡持有人領取。</li> ';
    this.html4rPdf += '                <li>新濠博亞會要求會員選擇一個保密的個人密碼(PIN)，密碼格式為新濠博亞指定。會員選擇的PIN只供個人使用。</li> ';
    this.html4rPdf += '                <li>會員不論任何理由都不得透露自己的PIN給他人或其他會員。</li> ';
    this.html4rPdf += '                <li>新濠博亞保留對已獲發PIN的會員參與任何獎賞、優惠或推廣活動之權利。</li> ';
    this.html4rPdf += '                <li>除經新濠博亞書面授權外，會員不得轉讓、取代、延續、更改或退還新濠博亞所提供的獎賞、優惠或推廣活動。</li> ';
    this.html4rPdf += '                <li>所有會員獎賞及優惠將會於48小時內累積到會員賬戶中。任何會員獎賞換領將於會員賬戶內自動扣除。</li> ';
    this.html4rPdf += '                <li>若發現會員獎賞及優惠屬欺詐所得，其新濠會/皇璽會/摩卡會會籍將被暫停或終止。</li> ';
    this.html4rPdf += '                <li>會員必須出示有效身份證明文件(附有照片)方可以換領任何優惠、補發會員卡、發PIN及參與任何新濠博亞的推廣活動。新濠博亞可隨時要求會員出示有效身份證明文件及更新其個人資料。</li> ';
    this.html4rPdf += '                <li>新濠博亞保留取消新濠會/皇璽會/摩卡會會籍之權利，無需作出任何通告或理由。在此情況下，會員獎賞及優惠即告無效。</li> ';
    this.html4rPdf += '                <li>新濠博亞將會在以下情況終止新濠會/皇璽會/摩卡會會籍：會員違反本條款及細則；會員提供不正確的個人資料、濫用或不適當地獲得新濠會/皇璽會/摩卡會的獎賞和優惠；在澳門新濠天地/新濠影滙/澳門新濠鋒/摩卡娛樂場內會員作出不守規矩或不檢點的行為等。</li> ';
    this.html4rPdf += '                <li>當會籍被終止時，所有會員獎賞及優惠亦會被取消。</li> ';
    this.html4rPdf += '                <li>未使用之濠賞分或摩卡積分將會在下一年之12月31日被視為過期及無效。例如﹕在2014年累積之濠賞分或摩卡積分，如未經使用，將於2015年12月31日內被取消。</li> ';
    this.html4rPdf += '                <li>若連續365日內會員卡內沒有娛樂活動紀錄，則新濠會/皇璽會/摩卡會會員獎賞(除濠賞分及摩卡積分)及優惠將被視為過期及無效。</li> ';
    this.html4rPdf += '                <li>新濠博亞有保留隨時終止、更改或修訂會籍升級的相關條款及細則，以及取消或重發新濠會/皇璽會/摩卡會會員卡的權利，無需另行通知或給予任何理由。</li> ';
    this.html4rPdf += '                <li>新濠博亞不必為錯誤累積會員獎賞及優惠而負上任何責任，當中包括因電腦或技術故障、操作員失誤、虛報或超出新濠博亞控制範圍的各項原因等。</li> ';
    this.html4rPdf += '                <li>會員同意新濠博亞收集所得的會員資料作為一般市場推廣之用。</li> ';
    this.html4rPdf += '                <li>倘若遺失或被竊會員卡，新濠博亞對其補發卡有獨立裁決權。新濠博亞保留收取補發卡需繳付費用之權利。</li> ';
    this.html4rPdf += '                <li>新濠會/皇璽會/摩卡會會員卡為新濠博亞所擁有，當新濠博亞要求時，會員必須即時無條件歸還會員卡。</li> ';
    this.html4rPdf += '                <li>新濠博亞保留隨時終止、更改或修訂在此的條款及細則的權利，並對一切爭論有最終決定權。</li> ';
    this.html4rPdf += '                <li>新濠博亞在此內容沒有申明特定獎賞、優惠及推廣活動內容的義務和責任。</li> ';
    this.html4rPdf += '                <li>若本條款之規則及內容與其他文字版本存有差異，則一切以中文版本之條款及細則為標準。</li> ';
    this.html4rPdf += '            </ol> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row" style="text-align: justify;"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 1; flex: 1;"> ';
    this.html4rPdf += '            <strong>Membership Terms and Conditions</strong> ';
    this.html4rPdf += '            <br /> ';
    this.html4rPdf += '            <ol> ';
    this.html4rPdf += '                <li>City Club/Signature Club/Mocha Club is the Marketing Program of 3nadh Resorts (Macau) Limited hereinafter referred to as (“3nadh”), and is only valid in its City of Dreams/Studio City Macau/Altira Macau/Mocha branded casinos</li> ';
    this.html4rPdf += '                <li>These Terms and Conditions define the basic rules for participating in the City Club/Signature Club/Mocha Club and are subject to changes</li> ';
    this.html4rPdf += '                <li>By submitting this application to 3nadh, you are requesting to become a City Club/Signature Club/Mocha Club Member 3nadh reserves the right at its sole discretion to accept this application If 3nadh accepts this application, a City Club/Signature Club/Mocha ';
    this.html4rPdf += '          Club Card shall be issued and the applicant shall be considered as a Member of the City Club/Signature Club/Mocha Club (hereinafter “Member”) The use of the City Club/Signature Club/Mocha Club Card and the associated Benefits and Rewards is deemed ';
    this.html4rPdf += '          as an acceptance of the City Club/Signature Club/Mocha Club terms and conditions </li> ';
    this.html4rPdf += '                <li>Only one membership per person is allowed </li> ';
    this.html4rPdf += '                <li>Membership is not open to persons under 21 years old or to legal entities or other groups or associations Valid proof of identification must be provided, while a facial photo of the applicant must be taken upon registration for the purpose of identity ';
    this.html4rPdf += '          verification and to avoid misuse of points</li> ';
    this.html4rPdf += '                <li>City Club/Signature Club/Mocha Club shall not charge any membership fee</li> ';
    this.html4rPdf += '                <li>Members will be issued with one City Club/Signature Club/Mocha Club Card displaying the applicant’s name and membership number </li> ';
    this.html4rPdf += '                <li>The City Club/Signature Club/Mocha Club Card is not transferable and may only be used by the Member</li> ';
    this.html4rPdf += '                <li>Rewards and other benefits must be redeemed by the City Club/Signature Club/Mocha Club Card owner</li> ';
    this.html4rPdf += '                <li>3nadh may request a Member to select a Personal Identification Number (“PIN”) in a format specified by 3nadh A PIN selected by a Member may only be used by that Member </li> ';
    this.html4rPdf += '                <li>The Member must not disclose his/her PIN to another person or Member for any purpose whatsoever</li> ';
    this.html4rPdf += '                <li>3nadh reserves the right to restrict a Member’s ability to participate in any Rewards, Benefits or Promotions by limiting eligibility to those Members issued with a PIN</li> ';
    this.html4rPdf += '                <li>The Rewards, Benefits or Promotions issued from time to time by 3nadh to the Members cannot be transferred, replaced, extended or otherwise changed or refunded, except if authorized in writing by 3nadh</li> ';
    this.html4rPdf += '                <li>All Rewards and/or Benefits shall be credited to the Member’s account within 48 hours Any redemption claim shall be automatically debited from the Member’s account</li> ';
    this.html4rPdf += '                <li>Signs of fraudulent accumulation of Rewards and/or Benefits will result in the suspension or termination of the City Club/Signature Club/Mocha Club membership</li> ';
    this.html4rPdf += '                <li>Photo identification of valid documents such as passport, Hong Kong or Macau identity cards will be required upon request for any redemption process, card replacement, PIN issuance as well as for any 3nadh activities 3nadh may from time to time require ';
    this.html4rPdf += '          the Member to produce or update the photo identification </li> ';
    this.html4rPdf += '                <li>3nadh reserves the right to cancel at any time the City Club/Signature Club/Mocha Club Program without any liabilities, prior notice or assigning any reasons In this event, all the Rewards and/or Benefits accumulated shall be automatically forfeited ';
    this.html4rPdf += '          without further notice </li> ';
    this.html4rPdf += '                <li>3nadh may terminate the City Club/Signature Club/Mocha Club membership if: Member breaches these Terms and Conditions; attempts to obtain awards or benefits of the City Club/Signature Club/Mocha Club program by providing false information or in any ';
    this.html4rPdf += '          other improper or abusive way; behaves unruly while in its City of Dreams/Studio City Macau/Altira Macau/Mocha branded casinos in the Macau SAR</li> ';
    this.html4rPdf += '                <li>Upon termination of membership, any Rewards, Benefits or Promotions shall be considered expired</li> ';
    this.html4rPdf += '                <li>All unutilized City Points or Mocha Points credited to the Member’s account in a calendar year shall automatically be forfeited on 31 December of the new calendar year For example, the accumulated unutilized City Points or Mocha Points earned in ';
    this.html4rPdf += '          2014 shall expire on 31 December </li> ';
    this.html4rPdf += '                <li>If there is not at least one gaming record within the last 365 consecutive days in the City Club/Signature Club/Mocha Club account, then all Rewards(excluding City Points and Mocha Points) and other Benefits will expire</li> ';
    this.html4rPdf += '                <li>3nadh shall have the absolute discretion to determine, change or amend the terms and conditions for upgrading, relegating and renewing the type of City Club/Signature Club/Mocha Club Card issued to the Member without prior notice and/or assigning ';
    this.html4rPdf += '          any reasons to the Members </li> ';
    this.html4rPdf += '                <li>3nadh shall not be liable for Rewards and/or Benefits which accumulate inaccurately as a result of a technical malfunction, operator fault, misrepresentation or any reason beyond the control of 3nadh</li> ';
    this.html4rPdf += '                <li>Member consents 3nadh in using information collected about them as part of their membership program for general marketing purposes</li> ';
    this.html4rPdf += '                <li>3nadh may replace lost or stolen cards at its sole discretion 3nadh reserves the right to charge a fee for replacement of membership cards</li> ';
    this.html4rPdf += '                <li>The City Club/Signature Club/Mocha Club Card is the property of 3nadh and must be returned unconditionally and immediately upon 3nadh’s request</li> ';
    this.html4rPdf += '                <li>3nadh has the right and is authorized by the Member to at any time and at its sole discretion, terminate, change or amend all or any of these Terms and Conditions The decision of 3nadh shall be final in the event of any dispute</li> ';
    this.html4rPdf += '                <li>Nothing contained herein shall be interpreted as an obligation of 3nadh to make available any particular Rewards, Benefits or Promotions </li> ';
    this.html4rPdf += '                <li>The Chinese version of these Terms and Conditions shall prevail whenever there is a discrepancy between the English and Chinese versions</li> ';
    this.html4rPdf += ' ';
    this.html4rPdf += '            </ol> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="section_header" style="height: 25px; line-height: 25px;"> ';
    this.html4rPdf += '        簽署 Signature ';
    this.html4rPdf += '  ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div class="info-row" style="text-align: justify;"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 1; flex: 1; font-size: 11px;"> ';
    this.html4rPdf += '            簽署此申請表即代表閣下授權新濠博亞（澳門）股份有限公司收集、使用、儲存並以自動或機械方式處理由填寫人提供的個人資料（包括被視為敏感的資料），用作新濠會/皇璽會/摩卡會營運及聯絡會員之用。填寫人同時表明許可新濠博亞（澳門）股份有限公司把收集到的個人資料轉交或透露予直接或間接受新濠國際發展有限公司管理或其所擁有之公司或個體，而這些公司或個體有可能屬於填寫人居住國家以外之地區。填寫人同意將資料交予作全球性的資料處理。新濠博亞（澳門）股份有限公司給予填寫人提取個人資料或提出資料更新或更改的權利。  ';
    this.html4rPdf += '            <br /> ';
    this.html4rPdf += '            By signing the below the applicant expressly authorizes 3nadh Resorts (Macau) Limited to collect, use, store, process and to treat automatically or mechanically any personal data provided by applicant (which includes data that might be considered sensitive) in connection with the operation of the City Club/Signature Club/Mocha Club Loyalty Program for the purposes of keeping contact with members. Furthermore, the applicant expressly authorizes 3nadh Resorts (Macau) Limited to transfer or to disclose any or all personal data to any other company or other entity directly or indirectly under the control, or owned by 3nadh International Development Limited, which may be located in a country other than the country of residence of the applicant. Applicant expressly consents to such worldwide data processing. 3nadh Resorts (Macau) Limited grants the right for all applicants to have access to their personal data, and to request the amendment of inaccurate data. ';
    this.html4rPdf += ' ';
    this.html4rPdf += '            <br /> ';
    this.html4rPdf += '            <br /> ';
    this.html4rPdf += '            本人聲明已年滿21歲及上述資料正確無誤。本人已仔細閱讀、完全明白及同意新濠會/皇璽會/摩卡會會員條款及細則，包括上述之授權。 ';
    this.html4rPdf += '			<br/> ';
    this.html4rPdf += '			I declare that I am 21 years of age or older and the above information is true and complete. I have carefully read and understood and agreed with the City Club/Signature Club/Mocha Club Terms and Conditions including the above authorization. ';
    this.html4rPdf += '    ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div style="width: 100%; display: -webkit-flex; display: flex; margin-top: 20px;"> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.65; flex: 0.65; font-size: 14px"><strong>申請人簽署 Signature of Applicant</strong></div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.35; flex: 0.35; margin-left: 5px; font-size: 14px"><strong>申請日期 Application Date</strong></div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div style="width: 100%; display: -webkit-flex; display: flex"> ';
    this.html4rPdf += '        <div class="box" style="-webkit-flex: 0.65; flex: 0.65;"> ';
    this.html4rPdf += '            <img id="footerSign" width="350px" src="" /> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '        <div class="box" style="-webkit-flex: 0.35; flex: 0.35; margin-left: 5px" id="footerAppDate"></div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <br /> ';
    this.html4rPdf += '    <div class="section_header" style="height: 25px; line-height: 25px;"> ';
    this.html4rPdf += '        職員專用 Internal Use Only ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '    <div style="width: 100%; display: -webkit-flex; display: flex; margin-top: 20px;"> ';
    this.html4rPdf += '        <div class="box" style="-webkit-flex: 0.5; flex: 0.5; height: 50px">員工<br /> ';
    this.html4rPdf += '            Host<b style="padding-left: 25px; font-size:14px" id="hostName"></b></div> ';
    this.html4rPdf += '        <div style="-webkit-flex: 0.5; flex: 0.5; margin-left: 5px"> ';
    this.html4rPdf += '            <div style="width: 100%; display: -webkit-flex; display: flex;"> ';
    this.html4rPdf += '                <div style="-webkit-flex: 0.5; flex: 0.5;"><input id="cod" type="checkbox"> City Club</div> ';
    this.html4rPdf += '                <div style="-webkit-flex: 0.5; flex: 0.5; margin-left: 10px;"><input id="altira" type="checkbox"> Altira Club</div> ';
    this.html4rPdf += '            </div> ';
    this.html4rPdf += '            <div style="width: 100%; display: -webkit-flex; display: flex;"> ';
    this.html4rPdf += '                <div style="-webkit-flex: 0.5; flex: 0.5;"><input id="msc" type="checkbox"> Signature Club</div> ';
    this.html4rPdf += '                <div style="-webkit-flex: 0.5; flex: 0.5; margin-left: 10px;"><input id="mocha" type="checkbox"> Mocha Club</div> ';
    this.html4rPdf += '            </div> ';
    this.html4rPdf += '        </div> ';
    this.html4rPdf += '    </div> ';
    this.html4rPdf += '</body> ';
    this.html4rPdf += ' ';
    this.html4rPdf += '</html> '
 
    this.shareDataService.insertCompHtml(this.html4rPdf); 
  }



  goBack() {
    this.router.navigate(['/Registration/Step4']);
  }

  preferredLanguages(langvalue) {    
        if(this.preferredLanguageOptions) {
            for (let j=0;j<this.preferredLanguageOptions.length;j++){
              if(this.preferredLanguageOptions[j].value == langvalue){
                return this.preferredLanguageOptions[j].label;
                }
             
        }
      }


}

getPreferredLanguages() {
  this.registrationService.getLanguageCodes().then(data => {
      if(data) {
          for (let i=0;i<data.length;i++) {
              this.preferredLanguageOptions.push({label:data[i].label, value:data[i].value});
          }
      }

  })

}
  private _getIdentificationType() {
    return new Promise((resolve, reject)=> {

      this.registrationService.getActiveCategoryLookupCodes("IDENTIFICATIONTYPE").then((res) => {
        if (res && res.length) {
          _.forEach(res, (idType) => {
            this.identificationTypeData[idType["code"]] = idType["value"];
          });
          resolve(this.identificationTypeData);
        }
      }, (err) => {
        console.log("[_getIdentificationType->getActiveCategoryLookupCodes] Network Error Code: " + err.status);
        reject(err);
      });

    });

 
  }

}
