import { Router } from '@angular/router';
import { DuplicateAccount } from './../../../dataModels/DuplicateAccount';

import { RegistrationService } from './../../../services/registration.service';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { DomSanitizer } from '@angular/platform-browser';

const DEFAULT_USER_IMG: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAADD0lEQVR4Xu2agXETQQxF9SuAdAAVBCoAKgAqCKkAOiDpIFRAqABSAdABqYB0QKjgM5/ZYxz7nL2zv842tzvj8Xhs61ZvtZJWK8TMB2aufzQAzQJmTqBtgZkbQHOCk20Bkk8i4mVEPI+IhxGhz4vjR0TcRsS3iLgCoM/pIx0ASSn8vig+RiGBOAeg97SRCoDkm4j4uOXsTwFcbilj7d/TAJiU7yaeBiEFAMlHEfHTuGryDU8B3Bhl/hWVBUAme2Ke7CcA2lLWkQXgV/H0zsneAjhyCkyxgOL1v7onWuS9cEcFuwWQPCthL4OBwqLk20YGgC8l4bFNckGQ3Q9kAFDi8ixD+4j4DkCJlW00ADaURRBJumUuygNgXTSrME20AWgW0LZA8wHNCSYSOIQooKPrgyQGvwGonGYbGWFw9pngRUS8tS3RXUEfALxzys6wAEcdcJ2O9tJYBgDtURVEMsYRAPkY27ADKOlwxpFYdwWvbJoXQVkAdGR1V4Xs1SAxSAFQrMAZDex1gM6SMgE4rSBl9VMtoFiBIyTaQ9+d+oLbqSzLI6lLzuMNn3MNYPkSdUNR/X9L2wLd40gqLMofjIVwrQtVd9hbxpAOoGyFsRAmUT7dB/RshyF3Bvba/317ZhILWJxArWboPu7WHEYDUCPk/n42FlC8vzy/wpicYHejU7vZ6Vpi9K6Dj8KowqH1EGTPBIvCuhLTgUVKu+O3QAiKXkqNLUC29gEk1fmlGoD9pFbZfjpxXgK42mabbgSgrLaqPlJc7TC7HGqbUUeKUubRVjEaAEm1vKksZS1OGghK+QsA52NkDQZQOj/U8rbrFa/pJ4tQ6WxQf+EgAGXVrZ0ZNS0M358NsYYqAJJadXt3lkHBISLkJE83ToUPXPlO73shrLUAko5ixpBVmuI3a4sqvQCSW92mULjvGb1ltXUA1Oa6795+LMgbAI+rBRGSyug+j5V+IL9/DUAZ5L+xYgEkM/p894XPSp9hH4D/0fy7BVjZBn0AUltcdm0KyxWnaiK06wlnP78ByCa87/JnbwF/AJVxDFA60Up+AAAAAElFTkSuQmCC';



@Component({
  selector: 'app-duplicate-account',
  templateUrl: './duplicate-account.component.html',
  styleUrls: ['./duplicate-account.component.css']
})
export class DuplicateAccountComponent implements OnInit {

  duplicateAccount:DuplicateAccount[];
  userImg:any;

  

  constructor(private registrationService : RegistrationService, private router:Router,
              private sanitizer:DomSanitizer) { 
    console.log("**************************constructor");
   
  }

  ngOnInit() {

    console.log("++++++++++++++++++++++++++++++++ngOnInit");
    this.getDuplicateContent();
    
  }

  async getDuplicateContent() {

    await this.getPatronPhotoIdentity();
    this.getDuplicateRecords();

  }
  getDuplicateRecords() {

      this.registrationService.changeEmitted$.subscribe(duplicateRecords => {
          this.duplicateAccount = new Array();
          this.duplicateAccount.push({
                patronNo : this.registrationService.getTempPatronNumber(),
                photoId:DEFAULT_USER_IMG,
                fName : duplicateRecords.patronName[0].firstName,
                mName : duplicateRecords.patronName[0].middleName,
                lName : duplicateRecords.patronName[0].lastName,
                dob:duplicateRecords.dateOfBirth,
                idType:duplicateRecords.identification[0].idType,
                idNo: duplicateRecords.identification[0].idNumber,
                stopCode:'abc'
          });
    })

  }

  getPatronPhotoIdentity() {
    this.registrationService.getPatronByPatronNumber(this.registrationService.getTempPatronNumber()).subscribe((resData)=> {
          if(resData["documentList"] != null && resData["documentList"][0]["documentType"]=== "Patron Photo") {
            let photoName = resData["documentList"][0]["documentName"];
            this.registrationService.getPatronPhoto(photoName).subscribe((returnObj)=> {

            if( photoName.split('.')[photoName.split('.').length-1] == 'png' ){
                this.userImg = 'data:image/png;base64,'+ returnObj.text();
            }else if( photoName.split('.')[photoName.split('.').length-1] == 'gif' ){
              this.userImg = 'data:image/gif;base64,'+ returnObj.text();
            }else{
              this.userImg = 'data:image/jpeg;base64,'+ returnObj.text();
            }
              this.duplicateAccount[0]["photoId"] = this.userImg;
            });
            

          }
    })
  }

  onCancel() {
      this.router.navigate(['/Registration/Step1']);
  }

}
