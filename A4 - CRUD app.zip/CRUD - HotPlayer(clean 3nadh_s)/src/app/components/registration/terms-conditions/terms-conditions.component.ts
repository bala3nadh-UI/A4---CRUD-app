import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShareDataService } from '../../../services/share-data.service';


@Component({
    moduleId: module.id,
    selector: 'app-terms-conditions',
    templateUrl: './terms-conditions.component.html',
    styleUrls: ['./terms-conditions.component.css']
})
export class TermsConditionsComponent implements OnInit {

    approved = false;
    patronId = null;
    patronNo:any;
    node1: any;
    node2: any;
    node3: any;

    print: boolean = true;

    constructor(
        private router: Router,
        private shareDataService: ShareDataService,
        private activatedRoute:ActivatedRoute
    ) {

    }

    ngOnInit() {
        this.print = this.shareDataService.print;
        this.activatedRoute.queryParams.subscribe(params=> {
            this.patronNo = params["patronNo"]
        })
    }

    back() {
        history.back();
    }

    checked() {

    }

    toSign() {
        this.node1 = document.getElementById('termsId1').innerHTML;
        this.node2 = document.getElementById('termsId2').innerHTML;
        this.shareDataService.insertTermsImg(this.node1, this.node2);
        this.router.navigate(['/Registration/Esign'],{queryParams:{patronNo:this.patronNo}});
    }

    arrowDown() {
        window.scrollTo(0, document.body.scrollHeight);
    }
}
