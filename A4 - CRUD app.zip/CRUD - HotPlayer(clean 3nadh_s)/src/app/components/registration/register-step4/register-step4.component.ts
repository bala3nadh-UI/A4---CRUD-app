import { ShareDataService } from './../../../services/share-data.service';
import { RegistrationService } from './../../../services/registration.service';
import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { RegistrationStep4Model, SelectItem}  from  "../../../dataModels/models";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RegisterErrorhandlerComponent } from '../register-errorhandler/register-errorhandler.component';
import { InfoType, DialogType } from '../enums';
import { PatronPhones } from '../../../dataModels/PatronPhones';

@Component({
  selector: 'app-register-step4',
  templateUrl: './register-step4.component.html',
  styleUrls: ['./register-step4.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterStep4Component extends RegisterErrorhandlerComponent implements OnInit {

 public selectedIDType = this.registrationService.getIDType();
 public defaultLang:string;
  step4UserRegFormGrp : FormGroup;
  // sources : SelectItem[];
  sources:SelectItem[] = [
        {
            "label":"----Select----",
            "value":null
        }
  ];
  areaCodes : SelectItem[] = [
      {
          "label":'----Select----',
          "value":null
      }
  ];
  preferredLanguageOptions : SelectItem[] = [
        {
            "label":"----Select----",
            "value":null
        }

  ];
  patronNo:string;

  phonesArr : any = [];

  title:string = '';

  regSource:string = '';

  constructor(private fb: FormBuilder, private router: Router, private activatedRoute:ActivatedRoute, 
      private registrationService: RegistrationService, private shareDataService: ShareDataService, private ref: ChangeDetectorRef) {
          super(); 
        this.getRegistrationSources();
        this.getPreferredLanguages();
        this.getAreaCodes();
    }

  ngOnInit() {
    let step3DataObj = this.shareDataService.getStep3DataObj();
    let l_gender:string = step3DataObj.gender?step3DataObj.gender:"";
    if("Male".toUpperCase() === l_gender.toUpperCase()) {
        this.title = "Mr"
    } else if("Female".toUpperCase() === l_gender.toUpperCase()) {
        this.title = "Miss"
    }
      let step4DataObj = this.shareDataService.getStep4DataObj();
  
      this.activatedRoute.queryParams.subscribe(params => {
        this.patronNo = params["patronNo"];
    });
    
    this.languageIdtype(this.selectedIDType);
      if(!step4DataObj) {
            this.step4UserRegFormGrp = this.fb.group({
                title : [this.title],
                registrationSource : ['', [Validators.required]],
                signupHost : [localStorage.getItem('userID')],
                phones:this.fb.array([this.areaCodesForm(), this.areaCodesHomeForm()]),
                preferredLanguage : [this.defaultLang],
                address:this.fb.array([this.addressForm()]),
                email : [''],
                sendSMS : [''],
                directMail : [''],
                sendEmail : ['']
               
            });
         
      } else {

            this.step4UserRegFormGrp = this.fb.group({
                title : [step4DataObj.title],
                registrationSource : [step4DataObj.registrationSource, [Validators.required]],
                signupHost : [localStorage.getItem('userID')],
                phones:this.fb.array([this.fb.group({
                    areaCode : [step4DataObj.phones[0].areaCode],
                    phoneNo : [step4DataObj.phones[0].phoneNo],
                    phoneType : ['Mobile']
            }
            ), this.fb.group({
                areaCode : [step4DataObj.phones[1].areaCode],
                phoneNo : [step4DataObj.phones[1].phoneNo],
                phoneType : ['Home']
                }
            )]),
                preferredLanguage : [step4DataObj.preferredLanguage],
                address:this.fb.array([this.fb.group({
                    addressLine1 : [step4DataObj.address[0].addressLine1],
                    addressLine2 : [step4DataObj.address[0].addressLine2],
                    country : [step4DataObj.address[0].country],
                    city : [step4DataObj.address[0].city],
                    postcode : [step4DataObj.address[0].postcode],
                    directMail : ['']
            })]),
                email : [step4DataObj.email],
                sendSMS : [step4DataObj.sendSMS],
                directMail : [step4DataObj.directMail],
                sendEmail : [step4DataObj.sendEmail]
            });
         
      }

    
    
    let l_areaCode = this.selectAreaCode(step3DataObj.country);
    //this.step4UserRegFormGrp.controls["signupHost"].reset({value: localStorage.getItem('userID'), disabled: true});
    let xCntrl = this.step4UserRegFormGrp.get('phones')['controls'];
    for(var i=0; i<xCntrl.length;i++) {
        xCntrl[i].controls.areaCode.patchValue(l_areaCode);
    }

    this.ref.markForCheck();
 
    
  }

  areaCodesForm():FormGroup {
        return this.fb.group({
                areaCode : [''],
                phoneNo : [''],
                phoneType : ['Mobile']
        }
        );
  }


   areaCodesHomeForm():FormGroup {
        return this.fb.group({
                areaCode :[''],
                phoneNo : [''],
                phoneType : ['Home']
        }
        );
  }

  addressForm() : FormGroup {
    return this.fb.group({
          addressLine1 : [''],
          addressLine2 : [''],
          country : [''],
          city : [''],
          postcode : [''],
         directMail : ['']
    });
  }

  reset() {
     this.step4UserRegFormGrp.reset({});
     this.ref.markForCheck();

  }

  onSubmit({ value, valid }: { value: RegistrationStep4Model, valid: boolean }) {
      
   
    if(this.validateMandatoryFields(value))
    {
      return;
    }
    if(this.validateInput(value)) {         
        this.shareDataService.setStep4DataObj(value);
        this.router.navigate(['/Registration/Step5'],{queryParams:{patronNo:this.registrationService.getTempPatronNumber()}}); 
      }
      
      
  }

  goBack() {
    this.router.navigate(['/Registration/Step3']);
  }

  getRegistrationSources() {
      let defaultSrc :SelectItem[] = [
        {
            "label":"----Select----",
            "value":null
        }
        ];
      let deviceRegistrationSource:SelectItem[] = [];
      let otherRegistrationSource:SelectItem[] = [];
        this.registrationService.getActiveSources().then(data=> {
            this.registrationService.getDeviceInfo().then(deviceRes => {
                if(data) {
                    for(let i=0;i<data.length;i++) {
                        if(data[i].registrationSourceCode.endsWith('-M')) {
                            if(deviceRes) {
                                if(data[i].registrationSourceName === deviceRes.registrationSourceName) {
                                    deviceRegistrationSource.push({label:data[i].registrationSourceName, value:data[i].registrationSourceCode});
                                    if(!this.shareDataService.getStep4DataObj()) {
                                        this.setRegSource(data[i].registrationSourceCode);
                                    } else {
                                        this.setRegSource(this.shareDataService.getStep4DataObj().registrationSource);
                                    }
                                } else {
                                    otherRegistrationSource.push({label:data[i].registrationSourceName, value:data[i].registrationSourceCode});
                                }

                            } else {
                                otherRegistrationSource.push({label:data[i].registrationSourceName, value:data[i].registrationSourceCode});
                            }
                               
                        }
                    }
                    this.sources = defaultSrc.concat(deviceRegistrationSource, otherRegistrationSource);
                        if(this.getRegSource()) {
                            this.step4UserRegFormGrp.patchValue({registrationSource:this.getRegSource()});
                    }
                    this.ref.markForCheck();
                }
            });
          
        });
        

  }

  getPreferredLanguages() {
      this.registrationService.getLanguageCodes().then(data => {
          if(data) {
              for (let i=0;i<data.length;i++) {
                  this.preferredLanguageOptions.push({label:data[i].label, value:data[i].value});
              }
          }

      })

  }

  getAreaCodes() {
      this.registrationService.getAreaCodeList().then(data=> {
          if(data) {
                for(let i=0;i<data.length;i++) {
                    this.areaCodes.push({label:data[i].label,value:data[i].value});
                }
          }
      });
  }

      okDialogClick(event) {
        switch(this.infoType) {
            case InfoType.REGISTER:
              this.router.navigate(['/Registration/Step5'],{queryParams:{patronNo:this.patronNo}}); 
            break;
            default:
                this.closeDialog();
            break;
        }
    }

    selectAreaCode(cntry) {

        if("HONG KONG" === cntry.toUpperCase()) {
            return "852";
        } else if("CHINA" === cntry.toUpperCase()) {
            return "86";
        } else if("MACAO" === cntry.toUpperCase()) {
            return "853";
        }

    }

    validateInput(value) {
         
        for(let i=0;i<value.phones.length;i++){
            if(value.phones[i].areaCode == undefined){
                value.phones[i].areaCode = '';
                }
            
        }
        
        return this.validateEmail(value.email)
    }

    validateEmail(email) {
        let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (email != null && email.length > 0 && !re.test(email)) {
            this.dialogMess("Invalid Email!.",InfoType.NONE, DialogType.INFO, this.router);
            return false;
          }

        return true;  
    }
    validateMandatoryFields(value){
        if((value.registrationSource === undefined) || (value.registrationSource === "") || (value.registrationSource === null)){
          this.dialogMess("Source is mandatory");
                return true;
        }  else {
          return false;
        }
    
      }
      languageIdtype(value){

        if(value === "IDMO") {
           this.defaultLang = 'CHT';
        } else if(value === "IDCV"){
            this.defaultLang = 'CHN';
         }  else if(value === "IDPS"){
            this.defaultLang = 'ENG';
        } else if(value === "IDEEP"){
            this.defaultLang = 'CHN';
        } else if(value === "IDHK"){
            this.defaultLang = 'CHT';
        }  else {
            this.defaultLang = null;
        }
            
        } 

        getRegSource() {
            return this.regSource;
        }

        setRegSource(regSource) {
            this.regSource = regSource;
        }


       

}
