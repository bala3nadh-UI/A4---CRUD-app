import { Component, OnInit } from '@angular/core';
import { InformationDialogService } from '../../services/information-dialog.service';

declare var $: any;

@Component({
    selector: 'information-dialog',
    templateUrl: './information-dialog.component.html',
    styleUrls: ['./information-dialog.component.css']
})
export class InformationDialogComponent implements OnInit {

    typeClass: string = "";
    infoDialog: any = {
        header: "",
        message: ""
    };

    constructor(
        private informationService: InformationDialogService,
    ) {
        
    }
    
    ngOnInit() {
        this.informationService.alertConfigChange.subscribe(config => {
            switch(config['header']){
                case "Error": this.typeClass = "modal-header bg-danger";
                    break;
                case "Info": this.typeClass = "modal-header bg-info";
                    break;
                case "Success": this.typeClass = "modal-header bg-success";
                    break;
                default: this.typeClass = "modal-header bg-info";
                    break;
            }
            this.infoDialog = config;
            $('#popup').modal('show');
        })
        
        $('#popup').on('hidden.bs.modal', e => {
            this.closeFun();
        })
    }

    closeFun() {
        this.infoDialog.close && this.infoDialog.close();
    }
    

}
