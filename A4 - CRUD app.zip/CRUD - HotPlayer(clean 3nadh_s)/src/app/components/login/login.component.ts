import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import { GlobalLangConstVariable, GlobalLangVariable } from '../../globals';
import { LoginService } from '../../services/login.service';
import { InformationDialogService } from '../../services/information-dialog.service';
import { LoadingService } from '../../services/loading.service';
import { ShareDataService } from '../../services/share-data.service';
import { RegistrationService } from '../../services/registration.service';

@Component({
    selector: 'app-home-page',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginPageComponent implements OnInit {

    userName: string = "";
    passWord: string = "";
    station: string = "";
    deviceInfo: any;
    submitFlag: boolean = false;

    constructor(
        private translate: TranslateService,
        private loginService: LoginService,
        private router: Router,
        private informationDialogService: InformationDialogService,
        private loadingService: LoadingService,
        private shareDataService: ShareDataService,
        private registerService:RegistrationService,
    ) {
        // translate.addLangs(GlobalLangConstVariable.LANGLIST);
        // translate.setDefaultLang(GlobalLangVariable.CURRENTLANG);
        // /* use default Lang*/
        // let browserLang = translate.getDefaultLang();
        // /*use browserLang */
        // /*let browserLang = translate.getBrowserLang();*/
        // translate.use(browserLang.match(GlobalLangConstVariable.LANGMATCH) ? browserLang : GlobalLangConstVariable.DEFAULTLANG);
    }

    ngOnInit() {
    }

    onSubmit() {
        this.submitFlag = true;
        if(this.userName && this.passWord  && this.station) {
            this.loadingService.showLoading();
            this.loadingService.hideLoading();       //By-passing Authentication
            this.router.navigate(['Registration']);  //By-passing Authentication
            /*this.loginService.login(this.userName, this.passWord).subscribe(res => {
                this.loadingService.hideLoading();
                if(res.isAuthenticated){
                    this.initUserLoginInformation(res);                                        
                }else{
                    //this.informationDialogService.alert({header: "Error", message: res.message});  //By-passing Authentication
                    this.router.navigate(['HotPlayer']);                                             //By-passing Authentication  
                }
            }, err => {
                this.loadingService.hideLoading();
                let msg = (err._body && JSON.parse(err._body).message) || "Server error. Please contact administration for help.";
                this.informationDialogService.alert({
                    header: "Error", 
                    message: msg, 
                    // close: () => {
                    //     this.router.navigate(['ModifyComp']);
                    // }
                });
            })*/
        }
    }
    
    initUserLoginInformation(userObj) {
        localStorage.setItem('refId',userObj.sid);
        localStorage.setItem('userName',userObj.userName);
        localStorage.setItem('userID',userObj.userID);
        localStorage.setItem('station',this.station.toLowerCase());

        //Device Location
        this.registerService.getDeviceInfo().then(res1 => {
            this.deviceInfo = res1;
            if (this.deviceInfo != undefined) {
                this.shareDataService.setDeviceInfo(this.deviceInfo);
                this.router.navigate(['Registration']);
            } else {
                this.informationDialogService.alert({header: "Info", message: "Please enter valid Station"});
            };           
        });

        let permissionArr  = new Set();

        /* for (let _rolePermissions of userObj.permissionObj.rolePermissions){
            for (let _permissionObj of _rolePermissions['resourcePermissions']){
                if( !!_permissionObj['resource'] ){
                    permissionArr.add(_permissionObj['resource']['id']);
                }
            }
        }
        localStorage.setItem('permissions', JSON.stringify(Array.from(permissionArr))); */
    }
}
