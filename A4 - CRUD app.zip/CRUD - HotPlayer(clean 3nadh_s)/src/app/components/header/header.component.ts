import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  

  @ViewChild('collapseref') collapseref;

  constructor(private router:Router) { }

  ngOnInit() {
  }

   showHotCardPlayer() {

     this.router.navigate(['HotPlayer']).then(() => {
          this.toggleState();
     });
 }

 showRegister() {
    this.router.navigate(['Registration']).then(() => {
        this.toggleState();
    });
 }

toggleState() { // click handler

    var classAtrr = this.collapseref.nativeElement.getAttribute("class");
        if(classAtrr.includes('in')) {
          classAtrr = classAtrr.replace(classAtrr, "navbar-collapse collapse");
          this.collapseref.nativeElement.setAttribute("class",classAtrr);
      }
       
  }

  logOut() {
      localStorage.clear();
      this.router.navigate(["AppLogin"]);
  }

}
