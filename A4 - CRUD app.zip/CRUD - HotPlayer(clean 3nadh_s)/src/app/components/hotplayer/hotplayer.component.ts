import { Component, OnInit, ViewChild, Inject, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import * as model from "../../dataModels/models";
import { HotPlayerService } from '../../services/hot-player.service';
import { ConfirmationService } from 'primeng/primeng';
import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'app-hotplayer',
  templateUrl: './hotplayer.component.html',
  styleUrls: ['./hotplayer.component.css'],
  //changeDetection: ChangeDetectionStrategy.OnPush
})
export class HotplayerComponent implements OnInit, OnDestroy {

  isIdentificationDialogVisible = false;
  isModifyDialogVisible = false;
  modifyObj:  any = {};
  updateLocationDetails:  any = {};

  responseObj:any = [];
  dataObj:model.HotPlayerInfo[];
  responseObj1:any = [];
  dataObj1 = [];
  showRowInTable: number=5;
  expandedItems:Array<any> = new Array<any>();
  applyExpandorCollapseIcon:string = "details-control";
  rejectedCount:number=0;
  isLocationSorted:boolean = false;
  isPatronNoSorted:boolean = false;
  isTierNoSorted:boolean = false;
  isTheoNoSorted:boolean = false;
  highlightSortedColumn:any = {
    'background-color': '#F5F5DC'
  }
  gamingDate:Date;

  private subscription;

  @ViewChild("iconData") iconDataRef;
  @ViewChild("outerDatatable") outerDatatable;

  constructor(
    //private ref: ChangeDetectorRef, 
    private hotPlayerService : HotPlayerService, 
    private confirmationService: ConfirmationService,
    @Inject(DOCUMENT) private document:Document) {      
      /*ref.detach();
      setInterval(() => {
        console.log("Change Detection..!");
        this.ref.detectChanges();
      }, 10000);*/
    }

  ngOnInit() {
    this.initiateHotCardedPlayer(); 
  }

   initiateHotCardedPlayer() {

    // fake response
      this.subscription = this.hotPlayerService.getNonCodedHotPlayer('').subscribe(responseObj => {
      //this.subscription = this.hotPlayerService.resolveGetAllHotPlayers().then(responseObj => {
        console.log("1st response");
        console.log(responseObj);
        /*this.responseObj=responseObj;
        console.log(responseObj.postTime);
        let l_gamingDate = responseObj.postTime.split(' ');
        if(l_gamingDate) {
             l_gamingDate = l_gamingDate[0].split('-');
            this.gamingDate = new Date(parseInt(l_gamingDate[0]), parseInt(l_gamingDate[1]), parseInt(l_gamingDate[2]));
        }
       
        console.log(this.gamingDate);
        this.dataObj =  <model.HotPlayerInfo[]> this.responseObj.data;*/
        this.dataObj1 = responseObj;
        this.isTheoNoSorted = true;
        this.isLocationSorted = false;
        this.isPatronNoSorted = false;
        this.isTierNoSorted = false;
        //this.ref.markForCheck();
      });

      // service response
     /*  this.hotCardplayerService.getNonCodedHotPlayer('').subscribe(responseObj => {
        console.log("1st response");
        console.log(responseObj);
        this.responseObj=responseObj;
        console.log(responseObj.postTime);
        let l_gamingDate = responseObj.postTime.split(' ');
        if(l_gamingDate) {
             l_gamingDate = l_gamingDate[0].split('-');
            this.gamingDate = new Date(parseInt(l_gamingDate[0]), parseInt(l_gamingDate[1]), parseInt(l_gamingDate[2]));
        }
       
        console.log(this.gamingDate);
        this.dataObj =  <model.HotCardPlayerPatronInfo[]> this.responseObj.data;
        this.isTheoNoSorted = true;
        this.isLocationSorted = false;
        this.isPatronNoSorted = false;
        this.isTierNoSorted = false;
      }, err => {

      }) */


  }

  expandAll() {
      this.expandedItems.push(...this.dataObj);
      this.iconDataRef.styleClass = "details-control-down";
      console.log(this.outerDatatable);

  }

  collapseAll() {
    /* this.expandedItems.forEach(element => {
          this.expandedItems.splice(element);
     }); */
      this.expandedItems = [];
      this.iconDataRef.styleClass = "details-control";
      this.initiateHotCardedPlayer();
  }

  clearAll() {
      this.outerDatatable.reset();
 }

  refresh() {
    this.iconDataRef.styleClass = "details-control";
    this.initiateHotCardedPlayer();
  }

  onRowExpand(event) {
    event.originalEvent.target.parentElement.className = 'details-control-down';
    let l_className = event.originalEvent.target.parentElement.parentElement.className;
    if(l_className.indexOf("sorted-color-code") < 0) {
      l_className = l_className +' '+ 'sorted-color-code';
    event.originalEvent.target.parentElement.parentElement.className = l_className;
    }
    
  }

  onRowCollapse(event) {
    event.originalEvent.target.parentElement.className = 'details-control';
    var l_className = event.originalEvent.target.parentElement.parentElement.className;
    var removeClass=" sorted-color-code";
    l_className = l_className.replace(removeClass,"");
    event.originalEvent.target.parentElement.parentElement.className = l_className;
  }

   rejected(rejectedDataObj, event) {
       this.confirmationService.confirm({
            header:'Offer Declined - '+rejectedDataObj.patronNo+' '+rejectedDataObj.patronLastName,
            message: 'Please confirm that the patron rejects the offer?',
            accept: () => {
              var sendRequestObj = {
                patronNumber:rejectedDataObj.patronNo,
                staffID: localStorage.getItem('userID'),
                action : 'Reject'
              }
                 this.hotPlayerService.resolveRejectHotPlayer(sendRequestObj).then(responseObj => {
                    // this.rejectedCount = this.rejectedCount+1;
                    this.rejectedCount = responseObj.rejectCounter;
                    this.expandedItems = this.expandedItems.map((item)=> {
                        return item;
                    }).filter((item)=> {
                      if(item.patronNo === rejectedDataObj.patronNo) {
                            item.rejectedCount = responseObj.rejectCounter;
                            return item;
                      }
                    });
                     let l_className = event.target.parentElement.parentElement.className;
                      if(l_className.indexOf("rejectedColorCode") < 0) {
                          l_className = l_className +' '+ 'rejectedColorCode';
                          event.target.parentElement.parentElement.className = l_className;
                      }

                  });
            },
             reject: () => {
               console.log("reject");
            }
        });
  }

  accepted(accptdDataObj, event) {
    this.modifyObj = accptdDataObj;
    this.isModifyDialogVisible = true;
    console.log(this.modifyObj);
  }

  scrollTo() {
    // window.scrollTo({ left: 0, top: 0, behavior: 'smooth' });
    this.document.body.scrollTop = 0;
  }

  getStyleForLocationSort() {

    if(this.isLocationSorted) {
        return this.highlightSortedColumn;
      }
  }

   getStyleForPatronNoSort() {
    
      if(this.isPatronNoSorted) {
        return this.highlightSortedColumn;
      }
  }

   getStyleForTierSort() {
    if(this.isTierNoSorted) {
        return this.highlightSortedColumn;
      }
  }

   getStyleForTheoSort() {
     if(this.isTheoNoSorted) {
        return this.highlightSortedColumn;
      }
  }

  identiChangePage(evnt) {

    console.log(evnt);
  }

  onSortFn(evnt) {
    if(evnt.field==="location") {
        this.isLocationSorted = true;
        this.isPatronNoSorted = false;
        this.isTierNoSorted = false;
        this.isTheoNoSorted = false;
    } else if(evnt.field==="patronNo") {
         this.isLocationSorted = false;
        this.isPatronNoSorted = true;
        this.isTierNoSorted = false;
        this.isTheoNoSorted = false;
    } else if(evnt.field==="tier") {
        this.isLocationSorted = false;
        this.isPatronNoSorted = false;
        this.isTierNoSorted = true;
        this.isTheoNoSorted = false;
    } else if(evnt.field==="theo") {
         this.isLocationSorted = false;
        this.isPatronNoSorted = false;
        this.isTierNoSorted = false;
        this.isTheoNoSorted = true;
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }


  addNewHotPlayer(head: string) {
    this.initDialogAdd();
    this.isIdentificationDialogVisible = true;
  }

  initDialogAdd() {
    //this.updateLocationDetails.patronNo = "";
    //this.updateLocationDetails.patronLastName = "";
    this.updateLocationDetails = {
      patronNo: "",
      tier: "",
      location: "",
      theo: "",
      patronLastName: "",
      lastRatingTime: "",
      codedHost: "",
      hostName: "",
      booking: [
        {
          dept: "",
          checkin: "",
          checkout: ""
        }
      ]
    }
  }

  onCancel() {
    this.isIdentificationDialogVisible = false;
  }

  onDialogSave() {
    this.hotPlayerService.resolveAddHotPlayer(this.updateLocationDetails).then(responseObj => {
      console.log(responseObj);
      this.isIdentificationDialogVisible = false;
    });
  }

  onModifyCancel() {
    this.isModifyDialogVisible = false;
  }

  onDialogModify() {
    this.confirmationService.confirm({
        header:'Offer Accepted - '+this.modifyObj.patronNo+' '+this.modifyObj.patronLastName,
        message: 'Please confirm that the patron accepts the offer and his entry should be removed from the list?',
        accept: () => {
          var sendRequestObj = {
            patronNumber:this.modifyObj.patronNo,
            checkin: this.modifyObj.booking[0].checkin,
            checkout : this.modifyObj.booking[0].checkout
          }
          this.hotPlayerService.resolveAcceptHotPlayer(sendRequestObj).then(responseObj => {
            console.log(responseObj);
            this.isModifyDialogVisible = false;
          });
        },
          reject: () => {
            console.log("reject");
        }
    });
  }

}
