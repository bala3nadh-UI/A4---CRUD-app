/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { HotplayerComponent } from './hotplayer.component';

describe('HotplayerComponent', () => {
  let component: HotplayerComponent;
  let fixture: ComponentFixture<HotplayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HotplayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HotplayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
