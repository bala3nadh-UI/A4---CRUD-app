// globalvariable

export const GlobalLangConstVariable = Object.freeze({
     DEFAULTLANG: 'en',
     LANGLIST:["en", "zh"],
     LANGMATCH: /en|zh/,
 });


export var GlobalLangVariable = {
    CURRENTLANG: 'en',  /*GlobalLangConstVariable.DEFAULTLANG*/
     
 }
