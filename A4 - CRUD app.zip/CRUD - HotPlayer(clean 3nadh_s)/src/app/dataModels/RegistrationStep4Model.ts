import { PatronAddress } from './PatronAddress';
import * as models from './models';
export interface RegistrationStep4Model {
  title?: string;
  selectedSource: string;
  signupHost?:string;
  selectedAreaCode?:string;
  mobileNumber?:number;
  address?: Array<models.PatronAddress>;
  directMail?: boolean;
}