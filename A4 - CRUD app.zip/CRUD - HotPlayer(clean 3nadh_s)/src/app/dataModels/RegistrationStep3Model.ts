import * as models from './models';

export interface RegistrationStep3Model {
  englishFirstName?: string;
  englishLastName?: string;
  chineseName?:string;
  dob?: string;
}