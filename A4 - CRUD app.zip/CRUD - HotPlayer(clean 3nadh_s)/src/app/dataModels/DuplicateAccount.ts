import * as models from './models';

export interface DuplicateAccount {

    patronNo? : string,
    photoId?: string,
    fName?:string,
    mName?:string,
    lName?:string,
    dob?:string,
    idType?:string,
    idNo?:String,
    stopCode?:string


}