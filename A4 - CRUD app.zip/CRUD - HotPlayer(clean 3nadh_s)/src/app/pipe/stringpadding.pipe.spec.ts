/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { StringpaddingPipe } from './stringpadding.pipe';

describe('StringpaddingPipe', () => {
  it('create an instance', () => {
    const pipe = new StringpaddingPipe();
    expect(pipe).toBeTruthy();
  });
});
