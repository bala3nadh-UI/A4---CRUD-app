import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stringpadding'
})
export class StringpaddingPipe implements PipeTransform {

  transform(value: any, args?: any): string {
    let result:string;

        let cVal = value.match(/\d+/).toString();

        return this.padLeft(cVal,args,undefined);

  }

  padLeft(value:any, length:any, leadingChar:any) {

         if (leadingChar === undefined) leadingChar = '0'; 
             return value.length < length ? (leadingChar + value).padLeft(length, leadingChar) : value; 

  }

}
