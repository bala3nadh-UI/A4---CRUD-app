import { DuplicateAccountComponent } from './components/registration/duplicate-account/duplicate-account.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

/*ImportComponents*/
import { LoginPageComponent } from './components/login/login.component';
import { ModifyCompPageComponent } from './components/modify-comp/modify-comp.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { RegisterStep1Component } from './components/registration/register-step1/register-step1.component';
import { RegisterStep2Component } from './components/registration/register-step2/register-step2.component';
import { RegisterStep3Component } from './components/registration/register-step3/register-step3.component';
import { RegisterStep4Component } from './components/registration/register-step4/register-step4.component';
import { RegisterStep5Component } from './components/registration/register-step5/register-step5.component';
import { TermsConditionsComponent } from './components/registration/terms-conditions/terms-conditions.component';
import { SignaturePadComponent } from './components/registration/signature-pad/signature-pad.component';
import { ConfirmComponent } from './components/confirm/confirm.component';
import { HotplayerComponent } from './components/hotplayer/hotplayer.component';

/* Router*/
const appRoutes: Routes = [
    { path: '', redirectTo: 'AppLogin', pathMatch: 'full' },
    { path: 'AppLogin', component: LoginPageComponent },
    { path: 'ModifyComp', component: ModifyCompPageComponent },
    { path: 'Registration', component: RegistrationComponent, children:[
        {path:'', redirectTo:'Step1', pathMatch:'full'}, 
        {path: 'Step1', component: RegisterStep1Component},
        {path: 'Step2', component: RegisterStep2Component},
        {path: 'Step3', component: RegisterStep3Component},
        {path: 'Step4', component: RegisterStep4Component},
        {path: 'Step5', component: RegisterStep5Component},
        { path: 'Terms', component: TermsConditionsComponent },
        { path: 'Esign', component: SignaturePadComponent },
        {path:'DuplicateAccount', component: DuplicateAccountComponent}
    ]},    
    { path: 'Confirm', component: ConfirmComponent },
    { path:'HotPlayer', component: HotplayerComponent}
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule { }
